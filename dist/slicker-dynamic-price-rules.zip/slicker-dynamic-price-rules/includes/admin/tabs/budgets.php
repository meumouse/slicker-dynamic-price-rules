<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
  
?>

<div id="budgets" class="nav-content">
  <table class="form-table">
      <tr>
        <th>
           <?php echo esc_html__( 'Ativar recurso de orçamentos', 'slicker-dynamic-price-rules' ) ?>
           <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para habilitar recurso de orçamentos, negociação de preços e outros detalhes.', 'slicker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
            <div class="form-check form-switch me-3">
               <input type="checkbox" class="toggle-switch" id="enable_budge_feature" name="enable_budge_feature" value="yes" <?php checked( isset( $settings['enable_budge_feature'] ) && $settings['enable_budge_feature'] == 'yes' ); ?> />
            </div>
        </td>
      </tr>
      <tr class="budget-container d-none">
         <td class="container-separator"></td>
      </tr>
      <tr class="budget-container d-none">
         <th>
            <div class="manage-budgets-container">
               <a class="sdpr-manage-budgets-trigger btn btn-outline-primary" href="#"><?php echo esc_html__( 'Gerenciar orçamentos', 'slicker-dynamic-price-rules' ) ?></a> 
               
               <div class="sdpr-manage-budgets-container">
                  <div class="sdpr-manage-budgets-content">
                     <div class="sdpr-manage-budgets-header">
                        <h5 class="sdpr-popup-title"><?php echo esc_html__( 'Gerenciar orçamentos de usuários', 'slicker-dynamic-price-rules' ); ?></h5>
                        <button class="sdpr-close-manage-budgets btn-close fs-lg" aria-label="Fechar"></button>
                     </div>
                     <div>
                        <?php
                        $user_budgets = get_option('slicker_dynamic_price_rules_user_budgets', array());
                        $user_budgets = maybe_unserialize( $user_budgets );

                        $budgets = array_filter( $user_budgets, function( $budget ) {
                           return isset( $budget['id'] );
                        });

                        if ( empty( $budgets ) ) {
                           ?>
                           <p><?php echo esc_html__('Não existem orçamentos no momento.', 'slicker-dynamic-price-rules'); ?></p>
                           <?php
                        } else {
                           foreach ( $budgets as $budget_id => $budget ) {
                              $options = get_option('slicker-dynamic-price-rules-setting');

                              // get current values
                              $current_budget_approvation = isset( $user_budgets[$budget_id]['customer_aprovation'] ) ? $user_budgets[$budget_id]['customer_aprovation'] : 'pending';
                              $current_budget_status = isset( $user_budgets[$budget_id]['status'] ) ? $user_budgets[$budget_id]['status'] : 'pending';
                              $current_budget_value = isset( $user_budgets[$budget_id]['value'] ) ? $user_budgets[$budget_id]['value'] : 0;
                              $current_budget_details = isset( $user_budgets[$budget_id]['details'] ) ? $user_budgets[$budget_id]['details'] : '';
                              $current_budget_aditional_info = isset( $user_budgets[$budget_id]['aditional_info_admin'] ) ? $user_budgets[$budget_id]['aditional_info_admin'] : '';
                              $current_budget_start_date = isset( $user_budgets[$budget_id]['start_date'] ) ? $user_budgets[$budget_id]['start_date'] : '';
                              $current_budget_end_date = isset( $user_budgets[$budget_id]['end_date'] ) ? $user_budgets[$budget_id]['end_date'] : '';

                              ?>
                              <label class="budget-id text-left d-block fs-lg"><?php echo sprintf( __( 'Orçamento #%s', 'slicker-dynamic-price-rules' ), esc_html( $budget['id'] ) ); ?></label>
                              <ul class="list-group">
                                 <li class="list-group-item">
                                    <div class="d-flex">
                                       <div class="d-grid align-items-start col-6 me-4">
                                          <div class="d-flex">
                                             <p class="prefix-client me-1"><?php echo __( 'Cliente:', 'slicker-dynamic-price-rules' ); ?></p>
                                             <?php

                                             if ( isset( $options['enable_name_field'] ) && $options['enable_name_field'] == 'yes' && isset( $options['enable_lastname_field'] ) && $options['enable_lastname_field'] == 'no' ) {
                                                ?>
                                                <p class="full-name"><?php echo esc_html( $budget['full_name'] ); ?></p>
                                                <?php
                                             } else {
                                                ?>
                                                <div class="d-flex">
                                                   <p class="first-and-last-name"><?php echo sprintf( __( '%s %s', 'slicker-dynamic-price-rules' ), esc_html( $budget['first_name'] ), esc_html( $budget['last_name'] ) ); ?></p>
                                                </div>
                                                <?php
                                             }
                                             ?>
                                          </div>
                                             <?php
                                             if ( $budget['person_type'] === 'cpf_field' ) {
                                                ?>
                                                <p class="cpf-field"><?php echo sprintf( __( 'CPF: %s', 'slicker-dynamic-price-rules' ), esc_html( $budget['pf_person'] ) ); ?></p>
                                                <?php
                                             } else {
                                                ?>
                                                <p class="cnpj-field"><?php echo sprintf( __( 'CNPJ: %s', 'slicker-dynamic-price-rules' ), esc_html( $budget['pj_person'] ) ); ?></p>
                                                <p class="social-reason-field"><?php echo sprintf( __( 'Razão social: %s', 'slicker-dynamic-price-rules' ), esc_html( $budget['social_reason'] ) ); ?></p>
                                                <?php
                                             }
                                             ?>

                                             <p class="number-phone-field"><?php echo sprintf( __( 'Telefone: %s', 'slicker-dynamic-price-rules' ), esc_html( $budget['phone_number'] ) ); ?></p>
                                             <p class="email-field"><?php echo sprintf( __( 'E-mail: %s', 'slicker-dynamic-price-rules' ), esc_html( $budget['user_email'] ) ); ?></p>
                                             <p class="id-field"><?php echo sprintf( __( 'ID do usuário: %s', 'slicker-dynamic-price-rules' ), esc_html( $budget['user_id'] ) ); ?></p>
                                             <p class="creation-date-field"><?php echo sprintf( __( 'Criado em: %s', 'slicker-dynamic-price-rules' ), esc_html( $budget['creation_date'] ) ); ?></p>
                                             <p class="service-type-field"><?php echo sprintf( __( 'Tipo do produto/serviço: %s', 'slicker-dynamic-price-rules' ), esc_html( $budget['service_type'] ) ); ?></p>
                                             <p class="service-deadline-field"><?php echo sprintf( __( 'Prazo máximo para execução do produto/serviço em dias úteis: %s', 'slicker-dynamic-price-rules' ), esc_html( $budget['service_deadline'] ) ); ?></p>
                                             <p class="aditional-info-field"><?php echo sprintf( __( 'Informações adicionais para execução do produto/serviço: %s', 'slicker-dynamic-price-rules' ), esc_html( $budget['aditional_info'] ) ); ?></p>
                                       </div>
                                       <div class="col-6 budget-actions">
                                          <div class="customer-aprovation mb-4">
                                                <?php
                                                if ( $budget['customer_aprovation'] === 'approved' ) {
                                                   echo '<span class="badge bg-translucent-success text-success">'. __( 'Este orçamento foi aceito pelo cliente', 'slicker-dynamic-price-rules' ) .'</span>';
                                                } elseif ( $budget['customer_aprovation'] === 'declined' ) {
                                                   echo '<span class="badge bg-translucent-danger text-danger">'. __( 'Este orçamento foi recusado pelo cliente', 'slicker-dynamic-price-rules' ) .'</span>';
                                                } elseif ( $budget['customer_aprovation'] === 'pending' ) {
                                                   echo '<span class="badge bg-translucent-warning text-warning">'. __( 'Este orçamento aguarda a resposta do cliente', 'slicker-dynamic-price-rules' ) .'</span>';
                                                }
                                                ?>
                                          </div>
                                          <div class="mb-4">
                                             <label class="form-label"><?php echo esc_html( 'Aprovação:', 'slicker-dynamic-price-rules' ); ?></label>
                                             <select name="manage_budget[<?php echo $budget_id ?>][customer_aprovation]" class="form-select">
                                                <option value="pending" <?php echo ( $current_budget_approvation === 'pending' ? 'selected="selected"' : ''); ?> ><?php echo __('Pendente', 'slicker-dynamic-price-rules'); ?></option>
                                                <option value="approved" <?php echo ( $current_budget_approvation === 'approved' ? 'selected="selected"' : ''); ?> ><?php echo __('Aceito', 'slicker-dynamic-price-rules'); ?></option>
                                                <option value="declined" <?php echo ( $current_budget_approvation === 'declined' ? 'selected="selected"' : ''); ?> ><?php echo __('Recusado', 'slicker-dynamic-price-rules'); ?></option>
                                             </select>
                                          </div>
                                          <div class="mb-4">
                                             <label class="form-label"><?php echo esc_html( 'Status:', 'slicker-dynamic-price-rules' ); ?></label>
                                             <select name="manage_budget[<?php echo $budget_id ?>][status]" class="form-select">
                                                <option value="pending" <?php echo ( $current_budget_status === 'pending' ? 'selected="selected"' : ''); ?> ><?php echo __('Pendente', 'slicker-dynamic-price-rules'); ?></option>
                                                <option value="in-progress" <?php echo ( $current_budget_status === 'in-progress' ? 'selected="selected"' : ''); ?> ><?php echo __('Em progresso', 'slicker-dynamic-price-rules'); ?></option>
                                                <option value="cancelled" <?php echo ( $current_budget_status === 'cancelled' ? 'selected="selected"' : ''); ?> ><?php echo __('Cancelado', 'slicker-dynamic-price-rules'); ?></option>
                                                <option value="completed" <?php echo ( $current_budget_status === 'completed' ? 'selected="selected"' : ''); ?> ><?php echo __('Concluído', 'slicker-dynamic-price-rules'); ?></option>
                                             </select>
                                          </div>
                                          <div class="mb-4">
                                             <label class="form-label"><?php echo esc_html( 'Valor:', 'slicker-dynamic-price-rules' ); ?></label>
                                             <div class="input-group">
                                                <span class="currency input-group-text"><?php echo get_woocommerce_currency_symbol(); ?></span>
                                                <input type="text" class="form-control input-control-wd-10" name="manage_budget[<?php echo $budget_id ?>][value]" value="<?php echo $current_budget_value ?>"/>
                                             </div>
                                          </div>
                                          <div class="mb-4">
                                             <label class="form-label"><?php echo esc_html( 'Data de início:', 'slicker-dynamic-price-rules' ); ?></label>
                                             <input type="text" class="dateselect form-control input-control-wd-10" name="manage_budget[<?php echo $budget_id ?>][start_date]" value="<?php echo $current_budget_start_date ?>"/>
                                          </div>
                                          <div class="mb-4">
                                             <label class="form-label"><?php echo esc_html( 'Data de finalização:', 'slicker-dynamic-price-rules' ); ?></label>
                                             <input type="text" class="dateselect form-control input-control-wd-10" name="manage_budget[<?php echo $budget_id ?>][end_date]" value="<?php echo $current_budget_end_date ?>"/>
                                          </div>
                                       </div>
                                    </div>
                                 </li>
                                 <li class="list-group-item">
                                    <p class="budget-details text-left d-block fs-lg"><?php echo __( 'Detalhes do orçamento', 'slicker-dynamic-price-rules' ); ?></p>
                                    <textarea class="form-control" id="budget-details-<?php echo $budget_id ?>" name="manage_budget[<?php echo $budget_id ?>][details]" rows="5" cols="33"><?php echo $current_budget_details ?></textarea>
                                 </li>
                                 <li class="list-group-item">
                                    <p class="budget-aditional-info text-left d-block fs-lg"><?php echo __( 'Observações adicionais', 'slicker-dynamic-price-rules' ); ?></p>
                                    <textarea class="form-control" name="manage_budget[<?php echo $budget_id ?>][aditional_info_admin]"><?php echo $current_budget_aditional_info ?></textarea>
                                 </li>
                              </ul>
                              <?php
                           }

                        } ?>
                     </div>
                  </div>
               </div>
            </div>
         </th>
      </tr>
      <tr class="budget-container d-none">
         <td class="container-separator"></td>
      </tr>
      <tr class="budget-container d-none">
         <th>
            <?php echo esc_html__( 'Nome da empresa / Razão social', 'slicker-dynamic-price-rules' ) ?>
            <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__( 'Informe o nome da empresa ou razão social que será exibido no cabeçalho dos orçamentos.', 'slicker-dynamic-price-rules' ) ?></span>
         </th>
         <td>
            <input type="text" class="form-control input-control-wd-20" name="text_social_reason_budget_header" value="<?php echo $settings['text_social_reason_budget_header'] ?>"/>
         </td>
      </tr>
      <tr class="budget-container d-none">
         <th>
            <?php echo esc_html__( 'CNPJ do cabeçalho dos orçamentos', 'slicker-dynamic-price-rules' ) ?>
            <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__( 'Informe o texto de CNPJ que será adicionado no cabeçalho dos orçamentos.', 'slicker-dynamic-price-rules' ) ?></span>
         </th>
         <td>
            <input type="text" class="form-control input-control-wd-20" name="text_cnpj_budget_header" value="<?php echo $settings['text_cnpj_budget_header'] ?>"/>
         </td>
      </tr>
      <tr class="budget-container d-none">
         <th>
            <?php echo esc_html__( 'Endereço da empresa', 'slicker-dynamic-price-rules' ) ?>
            <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__( 'Informe o endereço da empresa que será exibido no cabeçalho dos orçamentos. Ou deixe em branco para não exibir.', 'slicker-dynamic-price-rules' ) ?></span>
         </th>
         <td>
            <input type="text" class="form-control input-control-wd-20" name="text_address_budget_header" value="<?php echo $settings['text_address_budget_header'] ?>"/>
         </td>
      </tr>
      <tr class="budget-container d-none">
         <td class="container-separator"></td>
      </tr>
      <tr class="budget-container d-none">
        <th>
           <?php echo esc_html__( 'Ativar campo de nome', 'slicker-dynamic-price-rules' ) ?>
           <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para mostrar campo de nome, se o campo de sobrenome estiver desativado, este campo será considerado nome completo.', 'slicker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
            <div class="form-check form-switch me-3">
               <input type="checkbox" class="toggle-switch" id="enable_name_field" name="enable_name_field" value="yes" <?php checked( isset( $settings['enable_name_field'] ) && $settings['enable_name_field'] == 'yes' ); ?> />
            </div>
        </td>
      </tr>
      <tr class="budget-container d-none">
        <th>
           <?php echo esc_html__( 'Ativar campo de sobrenome', 'slicker-dynamic-price-rules' ) ?>
           <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para mostrar campo de sobrenome.', 'slicker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
            <div class="form-check form-switch me-3">
               <input type="checkbox" class="toggle-switch" id="enable_lastname_field" name="enable_lastname_field" value="yes" <?php checked( isset( $settings['enable_lastname_field'] ) && $settings['enable_lastname_field'] == 'yes' ); ?> />
            </div>
        </td>
      </tr>
      <tr class="budget-container d-none">
         <th>
            <?php echo esc_html__( 'Exibir Tipo de Pessoa', 'slicker-dynamic-price-rules' ) ?>
            <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__( 'Define qual Tipo de Pessoa será exibido, Pessoa Física, Jurícica, ambos ou nenhum.', 'slicker-dynamic-price-rules' ) ?></span>
         </th>
         <td>
            <select id="set_person_type_method" class="form-select" name="set_person_type_method">
              <option value="cpf_and_cnpj" <?php echo ( self::get_setting( 'set_person_type_method' ) == 'cpf_and_cnpj' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Pessoa Física e Jurídica (Padrão)', 'slicker-dynamic-price-rules' ) ?></option>
              <option value="cpf_only" <?php echo ( self::get_setting( 'set_person_type_method' ) == 'cpf_only' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Pessoa Física', 'slicker-dynamic-price-rules' ) ?></option>
              <option value="cnpj_only" <?php echo ( self::get_setting( 'set_person_type_method' ) == 'cnpj_only' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Pessoa Jurídica', 'slicker-dynamic-price-rules' ) ?></option>
              <option value="none" <?php echo ( self::get_setting( 'set_person_type_method' ) == 'none' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Nenhum', 'slicker-dynamic-price-rules' ) ?></option>
            </select>
         </td>
      </tr>
      <tr class="budget-container d-none">
        <th>
           <?php echo esc_html__( 'Ativar campo de Razão Social', 'slicker-dynamic-price-rules' ) ?>
           <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para mostrar campo de Razão Social da empresa.', 'slicker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
            <div class="form-check form-switch me-3">
               <input type="checkbox" class="toggle-switch" id="enable_social_reason_field" name="enable_social_reason_field" value="yes" <?php checked( isset( $settings['enable_social_reason_field'] ) && $settings['enable_social_reason_field'] == 'yes' ); ?> />
            </div>
        </td>
      </tr>
      <tr class="budget-container d-none">
        <th>
           <?php echo esc_html__( 'Ativar campo de telefone de contato', 'slicker-dynamic-price-rules' ) ?>
           <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para mostrar campo de telefone de contato.', 'slicker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
            <div class="form-check form-switch me-3">
               <input type="checkbox" class="toggle-switch" id="enable_phone_field" name="enable_phone_field" value="yes" <?php checked( isset( $settings['enable_phone_field'] ) && $settings['enable_phone_field'] == 'yes' ); ?> />
            </div>
        </td>
      </tr>
      <tr class="budget-container d-none">
        <th>
           <?php echo esc_html__( 'Ativar campo de e-mail', 'slicker-dynamic-price-rules' ) ?>
           <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para mostrar campo de e-mail, necessário para o envio de notificações por e-mail ao usuário.', 'slicker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
            <div class="form-check form-switch me-3">
               <input type="checkbox" class="toggle-switch" id="enable_email_field" name="enable_email_field" value="yes" <?php checked( isset( $settings['enable_email_field'] ) && $settings['enable_email_field'] == 'yes' ); ?> />
            </div>
        </td>
      </tr>
      <tr class="budget-container d-none">
        <th>
           <?php echo esc_html__( 'Ativar campo de tipo do serviço', 'slicker-dynamic-price-rules' ) ?>
           <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para permitir que o usuário informe o tipo de serviço do orçamento.', 'slicker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
            <div class="form-check form-switch me-3">
               <input type="checkbox" class="toggle-switch" id="enable_type_service_field" name="enable_type_service_field" value="yes" <?php checked( isset( $settings['enable_type_service_field'] ) && $settings['enable_type_service_field'] == 'yes' ); ?> />
            </div>
        </td>
      </tr>
      <tr class="budget-container d-none">
        <th>
           <?php echo esc_html__( 'Ativar campo de prazo máximo', 'slicker-dynamic-price-rules' ) ?>
           <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para permitir que o usuário informe o prazo máximo de execução do serviço.', 'slicker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
            <div class="form-check form-switch me-3">
               <input type="checkbox" class="toggle-switch" id="enable_deadline_field" name="enable_deadline_field" value="yes" <?php checked( isset( $settings['enable_deadline_field'] ) && $settings['enable_deadline_field'] == 'yes' ); ?> />
            </div>
        </td>
      </tr>
      <tr class="budget-container d-none">
        <th>
           <?php echo esc_html__( 'Ativar campo de informações adicionais', 'slicker-dynamic-price-rules' ) ?>
           <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para permitir que o usuário descreva informações adicionais sobre o serviço.', 'slicker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
            <div class="form-check form-switch me-3">
               <input type="checkbox" class="toggle-switch" id="enable_aditional_info_field" name="enable_aditional_info_field" value="yes" <?php checked( isset( $settings['enable_aditional_info_field'] ) && $settings['enable_aditional_info_field'] == 'yes' ); ?> />
            </div>
        </td>
      </tr>
  </table>
</div>