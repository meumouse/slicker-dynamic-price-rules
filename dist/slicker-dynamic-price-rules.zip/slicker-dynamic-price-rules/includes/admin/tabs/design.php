<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

?>

<div id="design" class="nav-content">
   <table class="form-table">
      <tr class="budget-container d-none">
         <th>
            <?php echo esc_html__( 'Logo para orçamentos', 'slicker-dynamic-price-rules' ) ?>
            <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__( 'Insira uma logo para ser exibida em orçamentos.', 'slicker-dynamic-price-rules' ) ?></span>
         </th>
         <td>
            <div class="input-group">
               <input type="text" name="display_logo_budgets" class="form-control" value="<?php echo $settings['display_logo_budgets'] ?>"/>
               <button id="get_logo_for_budgets" class="input-group-button btn btn-outline-primary"><?php echo esc_html__( 'Procurar', 'slicker-dynamic-price-rules' ) ?></button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Cor primária', 'slicker-dynamic-price-rules' ) ?>
            <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__( 'Define a cor primária que será usada nos elementos.', 'slicker-dynamic-price-rules' ) ?></span>
         </th>
         <td>
            <input type="color" name="set_primary_color" class="form-control-color" value="<?php echo isset( $settings['set_primary_color'] ) ? $settings['set_primary_color'] : '#008aff'; ?>"/>
         </td>
      </tr>
   </table>
</div>