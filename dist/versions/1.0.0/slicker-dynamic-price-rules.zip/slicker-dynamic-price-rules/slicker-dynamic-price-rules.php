<?php

/**
 * Plugin Name: 			Slicker - Regras de precificação dinâmicas para WooCommerce
 * Description: 			Transforme sua loja WooCommerce com descontos personalizados, orçamentos e configurações avançadas. Crie uma experiência de compra única!
 * Plugin URI: 				https://meumouse.com/plugins/slicker-regras-de-precificacao-dinamicas/
 * Author: 					MeuMouse.com
 * Author URI: 				https://meumouse.com/
 * Version: 				1.0.0
 * WC requires at least: 	6.0.0
 * WC tested up to: 		8.6.1
 * Requires PHP: 			7.4
 * Tested up to:      		6.4.3
 * Text Domain: 			slicker-dynamic-price-rules
 * Domain Path: 			/languages
 * License: 				GPL2
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Slicker_Dynamic_Price_Rules' ) ) {
  
/**
 * Main class
 *
 * @version 1.0.0
 * @since 1.0.0
 * @package MeuMouse.com
 */
class Slicker_Dynamic_Price_Rules {

		/**
		 * Slicker_Dynamic_Price_Rules The single instance of Slicker_Dynamic_Price_Rules.
		 *
		 * @var object
		 * @since 1.0.0
		 */
		private static $instance = null;

		/**
		 * The slug
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public static $slug = 'slicker-dynamic-price-rules';

		/**
		 * Plugin version number
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public static $version = '1.0.0';

		/**
		 * Constructor function
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function __construct() {
			$this->setup_constants();

			add_action( 'init', array( $this, 'load_plugin_textdomain' ), -1 );
			add_action( 'plugins_loaded', array( $this, 'slicker_dynamic_price_rules_load_checker' ), 5 );
		}
		

		/**
		 * Check requeriments on load plugin
		 * 
		 * @since 1.0.0
		 * @return void
		 */
		public function slicker_dynamic_price_rules_load_checker() {
			if ( !function_exists( 'is_plugin_active' ) ) {
				include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
			}

			// Display notice if PHP version is bottom 7.4
			if ( version_compare( phpversion(), '7.4', '<' ) ) {
				add_action( 'admin_notices', array( $this, 'slicker_dynamic_price_rules_php_version_notice' ) );
				return;
			}

			// check if WooCommerce is active
			if ( is_plugin_active( 'woocommerce/woocommerce.php' ) && version_compare( WC_VERSION, '6.0', '>' ) ) {
				add_action( 'before_woocommerce_init', array( $this, 'setup_hpos_compatibility' ) );
				add_action( 'plugins_loaded', array( $this, 'setup_includes' ), 10 );
				add_filter( 'plugin_action_links_' . SLICKER_DYNAMIC_PRICE_RULES_BASE, array( $this, 'slicker_dynamic_price_rules_plugin_links' ), 10, 4 );
			} else {
				deactivate_plugins( 'slicker-dynamic-price-rules/slicker-dynamic-price-rules.php' );
				add_action( 'admin_notices', array( $this, 'woo_custom_installments_wc_deactivate_notice' ) );
				add_action( 'admin_notices', array( $this, 'woo_custom_installments_wc_version_notice' ) );
			}
		}


		/**
		 * Setup WooCommerce High-Performance Order Storage (HPOS) compatibility
		 * 
		 * @since 1.0.0
		 * @return void
		 */
		public function setup_hpos_compatibility() {
			if ( defined( 'WC_VERSION' ) && version_compare( WC_VERSION, '7.1', '<' ) ) {
				return;
			}

			if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
				\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
					'custom_order_tables',
					SLICKER_DYNAMIC_PRICE_RULES_FILE,
					true
				);
			}
		}


		/**
		 * Main Slicker_Dynamic_Price_Rules Instance
		 *
		 * Ensures only one instance of Slicker_Dynamic_Price_Rules is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @see Slicker_Dynamic_Price_Rules()
		 * @return Main Slicker_Dynamic_Price_Rules instance
		 */
		public static function run() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}


		/**
		 * Define constant if not already set.
		 *
		 * @param string $name  Constant name.
		 * @param string|bool $value Constant value.
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}


		/**
		 * Setup plugin constants
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function setup_constants() {
			$this->define( 'SLICKER_DYNAMIC_PRICE_RULES_BASE', plugin_basename( __FILE__ ) );
			$this->define( 'SLICKER_DYNAMIC_PRICE_RULES_DIR', plugin_dir_path( __FILE__ ) );
			$this->define( 'SLICKER_DYNAMIC_PRICE_RULES_INC_DIR', SLICKER_DYNAMIC_PRICE_RULES_DIR . '/includes/' );
			$this->define( 'SLICKER_DYNAMIC_PRICE_RULES_URL', plugin_dir_url( __FILE__ ) );
			$this->define( 'SLICKER_DYNAMIC_PRICE_RULES_ASSETS_URL', SLICKER_DYNAMIC_PRICE_RULES_URL . '/assets/' );
			$this->define( 'SLICKER_DYNAMIC_PRICE_RULES_FILE', __FILE__ );
			$this->define( 'SLICKER_DYNAMIC_PRICE_RULES_ABSPATH', dirname( SLICKER_DYNAMIC_PRICE_RULES_FILE ) . '/' );
			$this->define( 'SLICKER_DYNAMIC_PRICE_RULES_SLUG', self::$slug );
			$this->define( 'SLICKER_DYNAMIC_PRICE_RULES_VERSION', self::$version );
		}


		/**
		 * What type of request is this?
		 *
		 * @param  string $type admin, ajax, cron or wciend.
		 * @return bool
		 */
		private function is_request( $type ) {
			switch ( $type ) {
				case 'admin':
					return is_admin();
				case 'ajax':
					return defined( 'DOING_AJAX' );
				case 'cron':
					return defined( 'DOING_CRON' );
			}
		}


		/**
		 * Include required files
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function setup_includes() {
			/**
			 * Class init plugin
			 * 
			 * @since 1.0.0
			 */
			include_once SLICKER_DYNAMIC_PRICE_RULES_INC_DIR . 'class-slicker-dynamic-price-rules-init.php';

			/**
			 * Load front-end class
			 * 
			 * @since 1.0.0
			 */
			include_once SLICKER_DYNAMIC_PRICE_RULES_INC_DIR . 'classes/class-slicker-dynamic-price-rules-frontend.php';

			/**
			 * Create conditions
			 * 
			 * @since 1.0.0
			 */
			include_once SLICKER_DYNAMIC_PRICE_RULES_INC_DIR . 'classes/class-slicker-dynamic-price-rules-conditions.php';

			/**
			 * Handle discounts
			 * 
			 * @since 1.0.0
			 */
			include_once SLICKER_DYNAMIC_PRICE_RULES_INC_DIR . 'classes/class-slicker-dynamic-price-rules-discounts.php';

			/**
			 * Admin options
			 * 
			 * @since 1.0.0
			 */
			include_once SLICKER_DYNAMIC_PRICE_RULES_INC_DIR . 'admin/class-slicker-dynamic-price-rules-admin-options.php';

			/**
			 * Custom colors
			 * 
			 * @since 1.0.0
			 */
			include_once SLICKER_DYNAMIC_PRICE_RULES_INC_DIR . 'classes/class-slicker-dynamic-price-rules-custom-colors.php';

			/**
			 * Load user levels class if enabled
			 * 
			 * @since 1.0.0
			 */
			if ( Slicker_Dynamic_Price_Rules_Init::get_setting('enable_user_levels') === 'yes' ) {
				include_once SLICKER_DYNAMIC_PRICE_RULES_INC_DIR . 'classes/class-slicker-dynamic-price-rules-user-levels.php';
			}
	
			/**
			 * Load budget class if enabled
			 * 
			 * @since 1.0.0
			 */
			if ( Slicker_Dynamic_Price_Rules_Init::get_setting('enable_budge_feature') === 'yes' ) {
				include_once SLICKER_DYNAMIC_PRICE_RULES_INC_DIR . 'classes/class-slicker-dynamic-price-rules-budget.php';
			}

			/**
			 * Update checker
			 * 
			 * @since 1.0.0
			 */
			include_once SLICKER_DYNAMIC_PRICE_RULES_INC_DIR . 'classes/class-slicker-dynamic-price-rules-updater.php';
		}

		/**
		 * PHP version notice
		 * 
		 * @since 1.0.0
		 */
		public function slicker_dynamic_price_rules_php_version_notice() {
			echo '<div class="notice is-dismissible error">
					<p>' . __( '<strong>Slicker - Regras de precificação dinâmicas para WooCommerce</strong> requer a versão do PHP 7.4 ou maior. Contate o suporte da sua hospedagem para realizar a atualização.', 'slicker-dynamic-price-rules' ) . '</p>
				</div>';
		}

		/**
		 * Plugin action links
		 * 
		 * @since 1.0.0
		 * @return array
		 */
		public function slicker_dynamic_price_rules_plugin_links( $action_links ) {
			$plugins_links = array(
				'<a href="' . admin_url( 'admin.php?page=slicker-dynamic-price-rules' ) . '">'. __( 'Configurar', 'slicker-dynamic-price-rules' ) .'</a>',
				'<a href="https://meumouse.com/docs/slicker-regras-de-precificacao-dinamicas-para-woocommerce/" target="_blank">'. __( 'Documentação', 'slicker-dynamic-price-rules' ) .'</a>'
			);

			return array_merge( $plugins_links, $action_links );
		}

		/**
		 * Load the plugin text domain for translation.
		 */
		public static function load_plugin_textdomain() {
			load_plugin_textdomain( 'slicker-dynamic-price-rules', false, dirname( SLICKER_DYNAMIC_PRICE_RULES_BASE ) . '/languages/' );
		}

		/**
		 * Get the plugin url.
		 *
		 * @return string
		 */
		public function plugin_url() {
			return untrailingslashit( plugins_url( '/', SLICKER_DYNAMIC_PRICE_RULES_FILE ) );
		}

		/**
		 * Cloning is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __clone() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'slicker-dynamic-price-rules' ), '1.0.0' );
		}

		/**
		 * Unserializing instances of this class is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'slicker-dynamic-price-rules' ), '1.0.0' );
		}
	}
}

/**
 * Initialise the plugin
 */
Slicker_Dynamic_Price_Rules::run();