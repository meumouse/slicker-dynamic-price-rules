<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class for handle discounts in WooCommerce
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */
class Slicker_Dynamic_Price_Rules_Discounts {
    
    /**
     * Construct function
     */
    public function __construct() {
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_action( 'woocommerce_cart_calculate_fees', array( $this, 'apply_user_level_discounts' ) );
        add_filter( 'woocommerce_gateway_title', array( $this, 'discount_method_title' ), 10, 2 );
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'update_order_meta_payment_title' ), 10 );
    }


    /**
	 * Include scripts on WooCommerce checkout
     * 
     * @since 1.0.0
     * @return void
	 */
	public function enqueue_scripts() {
		if ( is_checkout() && ! is_wc_endpoint_url( 'order-received' ) ) {
            wp_enqueue_script( 'sdpr-update-checkout', SLICKER_DYNAMIC_PRICE_RULES_ASSETS_URL . 'front/js/update-checkout.js', array('wc-checkout'), SLICKER_DYNAMIC_PRICE_RULES_VERSION );
            wp_enqueue_style( 'sdpr-update-checkout-styles', SLICKER_DYNAMIC_PRICE_RULES_ASSETS_URL . 'front/css/checkout-styles.css', array(), SLICKER_DYNAMIC_PRICE_RULES_VERSION );
		}
	}


	/**
     * Generate the discount name
     * 
     * @since 1.0.0
     * @param $value
     * @param $gateway
     * @return string
     */
    protected function discount_name( $value, $gateway ) {
        if ( strstr( $value, '%') ) {
            // Add the discount amount to the gateway title if it is a percentage.
            return sprintf( __( 'Desconto para %s (%s off)', 'slicker-dynamic-price-rules' ), esc_attr( $gateway->title ), $value );
        }

        return sprintf( __( 'Desconto para %s', 'slicker-dynamic-price-rules' ), esc_attr( $gateway->title ) );
    }


    /**
     * Display the discount in payment method title
     * 
     * @since 1.0.0
     * @param $title
     * @param $id
     * @return string
     */
    public function discount_method_title( $title, $id ) {
        if ( ! is_checkout() && ! ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {
            return $title;
        }
    
        $user_id = get_current_user_id();
        $user_level = get_user_meta( $user_id, 'user_level', true );
    
        // Gets the discount settings based on the user level
        $discount_conditions = get_option( 'slicker_dynamic_price_rules_discount_conditions_user_levels' );
        $discount_conditions = maybe_unserialize( $discount_conditions );
    
        // Checks if user level is set in discount settings
        if ( is_array( $discount_conditions ) && isset( $discount_conditions[ $user_level ] ) ) {
            $user_level_discounts = $discount_conditions[ $user_level ];
    
            if ( isset( $user_level_discounts['condition'] ) && $user_level_discounts['condition'] > 0 ) {
                for ( $i = 1; $i <= $user_level_discounts['condition']; $i++ ) {
                    // Checks if the current condition has a valid discount
                    if ( isset( $user_level_discounts[ $i ]['amount'] ) && $user_level_discounts[ $i ]['amount'] > 0 && ( $user_level_discounts[ $i ]['type'] === 'percentage' || $user_level_discounts[ $i ]['type'] === 'fixed' ) && $user_level_discounts[ $i ]['gateway'] === $id ) {
                        $gateway_discount = 0;
    
                        // Checks if the discount is a percentage and calculates the discount amount
                        if ( $user_level_discounts[ $i ]['type'] === 'percentage' ) {
                            $gateway_discount = $user_level_discounts[ $i ]['amount'] . __( '% off', 'slicker-dynamic-price-rules' );
                        } elseif ( $user_level_discounts[ $i ]['type'] === 'fixed' ) {
                            $gateway_discount = wc_price( $user_level_discounts[ $i ]['amount'] ) . __( ' off', 'slicker-dynamic-price-rules' );
                        }
    
                        if ( $gateway_discount !== '0% off' && $gateway_discount !== 'R$0,00 off' ) {
                            // Add the discount amount after the gateway name
                            $title .= ' <small class="sdpr-discount-badge">' . $gateway_discount . '</small>';
                        }
                    }
                }
            }
        }
    
        return $title;
    }


    /**
     * Apply discount per payment method per each user level
     * 
     * @since 1.0.0
     * @param $cart
     * @return void
     */
    public function apply_user_level_discounts( $cart ) {
        if ( is_admin() && !defined('DOING_AJAX') || is_cart() ) {
            return;
        }
    
        // Gets the ID of the chosen payment method
        $gateway_id = WC()->session->chosen_payment_method;
    
        if ( !$gateway_id ) {
            return;
        }
    
        $user_id = get_current_user_id();
        $user_level = get_user_meta($user_id, 'user_level', true);
    
        // Gets discount settings based on user level
        $discount_conditions = get_option('slicker_dynamic_price_rules_discount_conditions_user_levels');
        $discount_conditions = maybe_unserialize($discount_conditions);
    
        // Checks if user level is set in discount settings
        if ( is_array( $discount_conditions ) && isset( $discount_conditions[$user_level] ) ) {
            $user_level_discounts = $discount_conditions[$user_level];
            
            if ( isset( $user_level_discounts['condition']) && $user_level_discounts['condition'] > 0 ) {
                for ( $i = 1; $i <= $user_level_discounts['condition']; $i++ ) {
                    // Checks if the current condition has a valid discount
                    if ( isset( $user_level_discounts[$i]['amount'] ) && $user_level_discounts[$i]['amount'] > 0 && ( $user_level_discounts[$i]['type'] === 'percentage' || $user_level_discounts[$i]['type'] === 'fixed') && $user_level_discounts[$i]['gateway'] === $gateway_id ) {
                        $gateway_discount = 0;
    
                        // Checks if the discount is a percentage and calculates the discount amount
                        if ( $user_level_discounts[$i]['type'] === 'percentage' ) {
                            $gateway_discount = ($user_level_discounts[$i]['amount'] / 100) * $cart->cart_contents_total;
                        } elseif ( $user_level_discounts[$i]['type'] === 'fixed' ) {
                            $gateway_discount = $user_level_discounts[$i]['amount'];
                        }

                        $payment_gateways = WC()->payment_gateways->payment_gateways();
                        $gateway = $payment_gateways[ WC()->session->chosen_payment_method ];
                        $discount_name = $this->discount_name( $gateway_discount, $gateway );
    
                        if ( $gateway_discount > 0 ) {
                            $cart->add_fee( $discount_name, -$gateway_discount, true);
                        }
                    }
                }
            }
        }
    }
    

    /**
	 * Remove the discount in the payment method title
     * 
     * @since 1.0.0
     * @param $order_id
     * @return void
	 */
	public function update_order_meta_payment_title( $order_id ) {
		$payment_method_title = get_post_meta( $order_id, '_payment_method_title', true );
		$new_payment_method_title = preg_replace( '/<small>.*<\/small>/', '', $payment_method_title );
		// Save the new payment method title.
		$new_payment_method_title = sanitize_text_field( $new_payment_method_title );
		update_post_meta( $order_id, '_payment_method_title', $new_payment_method_title );
	}
}

new Slicker_Dynamic_Price_Rules_Discounts();