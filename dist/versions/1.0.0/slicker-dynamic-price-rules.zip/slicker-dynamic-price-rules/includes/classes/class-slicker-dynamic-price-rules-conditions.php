<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class for create conditions
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */
class Slicker_Dynamic_Price_Rules_Conditions {

    /**
     * Construct function
     */
    public function __construct() {
        $options = get_option( 'slicker-dynamic-price-rules-setting' );

        // check available gateways for each level
        if ( isset( $options['enable_user_levels'] ) && $options['enable_user_levels'] === 'yes' ) {
            add_filter( 'woocommerce_available_payment_gateways', array( $this, 'filter_available_payment_gateways' ) );
        }

        // apply discount for advanced condition
        add_action( 'woocommerce_cart_calculate_fees', array( $this, 'apply_discount_at_checkout' ), 10, 1 );

        // remove shipping method for advanced condition
        add_filter( 'woocommerce_package_rates', array( $this, 'unset_shipping_method' ), 10, 2 );

        // reduce limit of use for conditions on complete order
        add_action( 'woocommerce_order_status_completed', array( $this, 'set_use_limit_after_order' ), 10, 1 );
    }


    /**
     * Check available gateways for each level
     * 
     * @since 1.0.0
     * @param $available_gateways
     * @return string 
     */
    public function filter_available_payment_gateways( $available_gateways ) {
        $user_id = get_current_user_id();
        // get user level
        $user_level = get_user_meta( $user_id, 'user_level', true );
    
        if ( ! $user_level ) {
            return $available_gateways;
        }
    
        $enabled_payment_gateway = get_option( 'slicker_dynamic_price_rules_enable_payment_methods_condition' );
        $enabled_payment_gateway = maybe_unserialize( $enabled_payment_gateway );
    
        foreach ( $available_gateways as $gateway_id => $gateway ) {
            // Check if the gateway is active for the current user level
            if ( isset( $enabled_payment_gateway[$user_level][$gateway_id] ) && $enabled_payment_gateway[$user_level][$gateway_id] === 'yes' ) {
                // Allowed gateway, keep it in the list
                continue;
            } else {
                // Remove the disallowed gateway
                unset( $available_gateways[$gateway_id] );
            }
        }
    
        return $available_gateways;
    }


    /**
     * Advanced condition for apply discount
     * 
     * @since 1.0.0
     * @param WC_Cart $cart The cart object
     * @return void
     */
    public function apply_discount_at_checkout( $cart ) {
        $formatted_array = $this->get_advanced_conditions_array();
    
        foreach ( $formatted_array as $rule_id => $rule_data ) {
            $rule_type = $rule_data['rule_type'];
            
            // Verificar se o tipo de regra é "desconto"
            if ( $rule_type !== 'discount' ) {
                continue;
            }
    
            // check conditions for specific user or roles
            $discount_options = $rule_data['discount_options'];
            $user_id = get_current_user_id();
            $user_roles = get_userdata( $user_id )->roles;
            $user_role = $discount_options['user_role'];
            $specific_users = $discount_options['specific_users'];
            $specific_role = $discount_options['specific_role'];
            $check_specific_users_roles = $this->check_specific_user_or_roles( $user_id, $user_role, $specific_users, $specific_role, $user_roles );
    
            // check conditions for specific products, categories or attributes
            $product_filter = $discount_options['product_filter'];
            $get_id_specific_products = $discount_options['specific_products'];
            $get_id_specific_categories = $discount_options['specific_categories'];
            $get_id_specific_attributes = $discount_options['specific_attributes'];
            $cart = WC()->cart;

            foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
                // Get cart item information
                $product_id = $cart_item['product_id'];
            }

            $check_product_filter = $this->check_product_filter( $product_filter, $get_id_specific_products, $product_id, $get_id_specific_categories, $get_id_specific_attributes );
    
            // Verifique as condições para continuar
            $apply_condition = $discount_options['apply_condition'];
            $current_operator_condition = $discount_options['operator_condition'];
            $condition_value = $discount_options['condition_value'];
            $check_conditions = $this->check_conditions( $cart, $current_operator_condition, $condition_value, $apply_condition, $user_id );
    
            // Verifique o uso limite ou datas
            $use_limit = $discount_options['use_limit'];
            $start_date = $discount_options['start_date'];
            $end_date = $discount_options['end_date'];
            $check_use_limit = $this->check_dates_and_limits( $user_id, $rule_id, $use_limit, $start_date, $end_date );
    
            // Pare se alguma condição não for atendida
            if ( $check_product_filter === false || $check_conditions === false || $check_use_limit === false || $check_specific_users_roles === false ) {
                continue;
            }
    
            // Inicialize o valor do desconto
            $discount_amount = 0;
    
            foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
                $quantity = $cart_item['quantity'];
                $min_quantity = (int) $discount_options['min_qtd'];
    
                if ( $discount_options['apply_discount_method'] === 'cart' ) {
                    if ( $discount_options['discount_method'] === 'percentage' ) {
                        $item_price = $cart_item['data']->get_price();
                        $item_discount = ( ( $item_price * $discount_options['discount_value'] ) / 100 ) * $quantity;
                        $discount_amount += $item_discount;
                    } elseif ( $discount_options['discount_method'] === 'fixed' ) {
                        $discount_amount += $discount_options['discount_value'];
                    }
                } elseif ( $discount_options['apply_discount_method'] === 'quantity' ) {
                    if ( $quantity >= $min_quantity ) {
                        if ( $discount_options['discount_method'] === 'percentage' ) {
                            $item_price = $cart_item['data']->get_price();
                            $item_discount = ( ( $item_price * $discount_options['discount_value'] ) / 100 ) * $quantity;
                            $discount_amount += $item_discount;
                        } elseif ( $discount_options['discount_method'] === 'fixed' ) {
                            $discount_amount += $discount_options['discount_value'];
                        }
                    }
                }

                // Verifique se há um desconto para aplicar
                if ( $discount_amount > 0 ) {
                    WC()->cart->add_fee( __( 'Desconto exclusivo', 'slicker-dynamic-price-rules' ), -$discount_amount );
                }
            }
        }
    }


    /**
     * Remove shipping method if any matched for advanced conditions
     * 
     * @since 1.0.0
     * @param $available_shipping_methods
     * @param $package
     * @return string $available_shipping_methods
     */
    public function unset_shipping_method( $available_shipping_methods, $package ) {
        // Get array of advanced condition options
        $formatted_array = $this->get_advanced_conditions_array();
    
        // Array para armazenar os métodos de envio a serem removidos
        $methods_to_remove = array();
    
        // Iterar sobre cada regra de envio
        foreach ( $formatted_array as $rule_id => $rule_data ) {
            if ( isset( $rule_data['rule_type'] ) && $rule_data['rule_type'] === 'shipping' ) {
                $shipping_options = $rule_data['shipping_options'];
                $user_id = get_current_user_id();
                $user_roles = get_userdata( $user_id )->roles;
    
                // Verifique se a regra se aplica ao usuário atual
                $user_role = $shipping_options['user_role'];
                $specific_users = $shipping_options['specific_users'];
                $specific_role = $shipping_options['specific_role'];
                $check_specific_users_roles = $this->check_specific_user_or_roles( $user_id, $user_role, $specific_users, $specific_role, $user_roles );
    
                // Verifique se a regra se aplica aos produtos no carrinho
                $product_filter = $shipping_options['product_filter'];
                $get_id_specific_products = $shipping_options['specific_products'];
                $get_id_specific_categories = $shipping_options['specific_categories'];
                $get_id_specific_attributes = $shipping_options['specific_attributes'];
                $cart = WC()->cart;

                foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
                    // Get cart item information
                    $product_id = $cart_item['product_id'];
                }

                $check_product_filter = $this->check_product_filter( $product_filter, $get_id_specific_products, $product_id, $get_id_specific_categories, $get_id_specific_attributes );
    
                // Verifique as condições para continuar
                $apply_condition = $shipping_options['apply_condition'];
                $current_operator_condition = $shipping_options['operator_condition'];
                $condition_value = $shipping_options['condition_value'];
                $check_conditions = $this->check_conditions( $cart, $current_operator_condition, $condition_value, $apply_condition, $user_id );
    
                // Verifique o uso limite ou datas
                $use_limit = $shipping_options['use_limit'];
                $start_date = $shipping_options['start_date'];
                $end_date = $shipping_options['end_date'];
                $check_use_limit = $this->check_dates_and_limits( $user_id, $rule_id, $use_limit, $start_date, $end_date );

                // Verifique se todas as condições são atendidas
                if ( $check_product_filter === false || $check_conditions === false || $check_use_limit === false || $check_specific_users_roles === false ) {
                    return $available_shipping_methods;
                } else {
                    $shipping_method_to_remove = $shipping_options['shipping_method'];
                    $methods_to_remove[] = $shipping_method_to_remove;
                }
            }
        }
    
        // Remova os métodos de envio correspondentes
        foreach ( $methods_to_remove as $method ) {
            foreach ( $available_shipping_methods as $shipping_id => $shipping ) {
                // Split the shipping_id to get only the method name
                $method_parts = explode( ':', $shipping_id );
                $method_name = $method_parts[0];
    
                // Check if the shipping method to remove matches (without the identifier)
                if ( $method_name === $method ) {
                    // Remove o método de envio
                    unset( $available_shipping_methods[ $shipping_id ] );
                }
            }
        }
    
        return $available_shipping_methods;
    }


    /**
     * Get formatted array for use on apply advanced conditions
     * 
     * @since 1.0.0
     * @return array $formatted_array
     */
    public function get_advanced_conditions_array() {
        $advanced_conditions = get_option( 'slicker_dynamic_price_rules_advanced_conditions' );
        $advanced_conditions = maybe_unserialize( $advanced_conditions );
        $formatted_array = array();

        $options = get_option( 'slicker-dynamic-price-rules-setting' );
        $loop_number = $options['get_loop_value_advanced_conditions'];
    
        for ( $a = 1; $a <= $loop_number; $a++ ) {
            $current_rule_type = isset( $advanced_conditions[$a]['rule_type'] ) ? $advanced_conditions[$a]['rule_type'] : 0;
            $current_user_role = isset( $advanced_conditions[$a]['user_role'] ) ? $advanced_conditions[$a]['user_role'] : 'all_users';
            $current_product_filter = isset( $advanced_conditions[$a]['product_filter'] ) ? $advanced_conditions[$a]['product_filter'] : 'all_products';
            $current_apply_discount_method = isset( $advanced_conditions[$a]['apply_discount_method'] ) ? $advanced_conditions[$a]['apply_discount_method'] : 'cart';
            $current_min_qtd_for_apply_discount = isset( $advanced_conditions[$a]['min_qtd'] ) ? $advanced_conditions[$a]['min_qtd'] : 0;
            $current_discount_method = isset( $advanced_conditions[$a]['discount_method'] ) ? $advanced_conditions[$a]['discount_method'] : 'percentage';
            $current_discount_value = isset( $advanced_conditions[$a]['discount_value'] ) ? $advanced_conditions[$a]['discount_value'] : 0;
            $current_shipping_method = isset( $advanced_conditions[$a]['shipping_method'] ) ? $advanced_conditions[$a]['shipping_method'] : 0;
            $current_shipping_operator = isset( $advanced_conditions[$a]['shipping_operator'] ) ? $advanced_conditions[$a]['shipping_operator'] : 0;
            $current_apply_condition = isset( $advanced_conditions[$a]['apply_condition'] ) ? $advanced_conditions[$a]['apply_condition'] : 0;
            $current_operator_condition = isset( $advanced_conditions[$a]['operator_condition'] ) ? $advanced_conditions[$a]['operator_condition'] : 0;
            $current_condition_value = isset( $advanced_conditions[$a]['condition_value'] ) ? $advanced_conditions[$a]['condition_value'] : '';
            $current_use_limit = isset( $advanced_conditions[$a]['use_limit'] ) ? $advanced_conditions[$a]['use_limit'] : '';
            $current_start_date = isset( $advanced_conditions[$a]['start_date'] ) ? $advanced_conditions[$a]['start_date'] : '';
            $current_end_date = isset( $advanced_conditions[$a]['end_date'] ) ? $advanced_conditions[$a]['end_date'] : '';
            $current_specific_products = isset( $advanced_conditions[$a]['specific_products'] ) ? $advanced_conditions[$a]['specific_products'] : '';
            $current_specific_categories = isset( $advanced_conditions[$a]['specific_categories'] ) ? $advanced_conditions[$a]['specific_categories'] : '';
            $current_specific_attributes = isset( $advanced_conditions[$a]['specific_attributes'] ) ? $advanced_conditions[$a]['specific_attributes'] : ''; 
            $current_specific_users = isset( $advanced_conditions[$a]['specific_users'] ) ? $advanced_conditions[$a]['specific_users'] : '';
            $current_specific_role = isset( $advanced_conditions[$a]['specific_roles'] ) ? $advanced_conditions[$a]['specific_roles'] : 'customer';
    
            $formatted_array[$a] = array('rule_type' => $current_rule_type);
    
            if ( $current_rule_type == 'discount' ) {
                $formatted_array[$a]['discount_options'] = array(
                    'user_role' => $current_user_role,
                    'product_filter' => $current_product_filter,
                    'apply_discount_method' => $current_apply_discount_method,
                    'min_qtd' => $current_min_qtd_for_apply_discount,
                    'discount_method' => $current_discount_method,
                    'discount_value' => $current_discount_value,
                    'apply_condition' => $current_apply_condition,
                    'operator_condition' => $current_operator_condition,
                    'condition_value' => $current_condition_value,
                    'use_limit' => $current_use_limit,
                    'start_date' => $current_start_date,
                    'end_date' => $current_end_date,
                    'specific_products' => $current_specific_products,
                    'specific_categories' => $current_specific_categories,
                    'specific_attributes' => $current_specific_attributes,
                    'specific_users' => $current_specific_users,
                    'specific_role' => $current_specific_role,
                );
            } elseif ( $current_rule_type == 'shipping' ) {
                $formatted_array[$a]['shipping_options'] = array(
                    'user_role' => $current_user_role,
                    'product_filter' => $current_product_filter,
                    'shipping_method' => $current_shipping_method,
                    'shipping_operator' => $current_shipping_operator,
                    'apply_condition' => $current_apply_condition,
                    'operator_condition' => $current_operator_condition,
                    'condition_value' => $current_condition_value,
                    'use_limit' => $current_use_limit,
                    'start_date' => $current_start_date,
                    'end_date' => $current_end_date,
                    'specific_products' => $current_specific_products,
                    'specific_categories' => $current_specific_categories,
                    'specific_attributes' => $current_specific_attributes,
                    'specific_users' => $current_specific_users,
                    'specific_role' => $current_specific_role,
                );
            }
        }
    
        return $formatted_array;
    }


    /**
     * Check specific user or roles
     * 
     * @since 1.0.0
     * @param $user_id
     * @param $user_role
     * @param $specific_users
     * @param $specific_role
     * @param $user_roles
     * @return bool
     */
    public function check_specific_user_or_roles( $user_id, $user_role, $specific_users, $specific_role, $user_roles ) {
        // check application on users or roles
        if ( $user_role === 'specific_user' ) {
            $allowed_user_ids = explode(',', $specific_users);

            // Stop if user ID is not in array
            if ( !in_array( $user_id, $allowed_user_ids ) ) {
                return false;
            } else {
                return true;
            }
        } elseif ( $user_role === 'specific_role' ) {
            $specific_role_id = $specific_role;
            
            // Stop if user role is not in array
            if ( !in_array( $specific_role_id, $user_roles ) ) {
                return false;
            } else {
                return true;
            }
        }
    }


    /**
     * Check product filter for apply condition
     * 
     * @since 1.0.0
     * @param $product_filter
     * @param $get_id_specific_products
     * @param $product_id
     * @param $get_id_specific_categories
     * @param $get_id_specific_attributes
     * @return bool
     */
    public function check_product_filter( $product_filter, $get_id_specific_products, $product_id, $get_id_specific_categories, $get_id_specific_attributes ) {
        // Verify that the product meets the product filter conditions
        if ( $product_filter === 'select_specific_products' ) {
            $specific_product_id = explode(',', $get_id_specific_products);

            if ( !in_array( $product_id, $specific_product_id ) ) {
                return false;
            } else {
                return true;
            }
        }

        // Check if the item is in specific categories (if applicable)
        if ( $product_filter === 'select_specific_categories' ) {
            $product_categories = wp_get_post_terms( $product_id, 'product_cat', array('fields' => 'ids') );
        
            // Converta $get_id_specific_categories em um array se não for
            if ( !is_array( $get_id_specific_categories ) ) {
                $get_id_specific_categories = explode(',', $get_id_specific_categories);
            }
        
            // Remove extra whitespace and convert to integers
            $get_id_specific_categories = array_map('trim', $get_id_specific_categories);
            $get_id_specific_categories = array_map('intval', $get_id_specific_categories);
        
            // Check if any of the specific category IDs are present in the product categories
            $intersection = array_intersect( $get_id_specific_categories, $product_categories );
        
            if ( !empty( $intersection ) ) {
                return true;
            } else {
                return false;
            }
        }
        

        // Check if the item has specific attributes (if applicable)
        if ( $product_filter === 'select_specific_attributes' ) {
            $product_attributes = wc_get_product($product_id)->get_attributes();
    
            // Transform the list of IDs into an array and remove extra whitespace
            $specific_attributes_array = array_map('trim', explode(',', $get_id_specific_attributes));
    
            foreach ( $product_attributes as $attribute_key => $attribute ) {
                $attribute_terms = wc_get_product_terms($product_id, $attribute_key, array('fields' => 'ids'));
                $intersection = array_intersect($specific_attributes_array, $attribute_terms);

                if ( !empty( $intersection ) ) {
                    return true;
                } else {
                    return false;
                }
            }
        }
    }


    /**
     * Get conditional operator
     * 
     * @since 1.0.0
     * @param $operator_condition
     * @return string
     */
    public function get_conditional_operator( $operator_condition ) {
        switch ( $operator_condition ) {
            case 'less_than':
                return '<';
            case 'less_than_or_equal':
                return '<=';
            case 'greater_than':
                return '>';
            case 'greater_than_or_equal':
                return '>=';
            case 'equal':
                return '==';
            case 'different':
                return '!=';
            case '0':
                return '';
            default:
                return '';
        }
    }


    /**
     * Check conditions for continue
     * 
     * @since 1.0.0
     * @param $cart
     * @param $current_operator_condition
     * @param $condition_value
     * @param $apply_condition
     * @param $user_id
     * @return bool
     */
    public function check_conditions( $cart, $current_operator_condition, $condition_value, $apply_condition, $user_id ) {
        // get conditional operator for compare values
        $conditional_operator = $this->get_conditional_operator( $current_operator_condition );

        // validate operator condition
        if ( $apply_condition !== '0' && empty( $current_operator_condition ) || $apply_condition !== '0' && $current_operator_condition === '0' ) {
            return false;
        }

        if ( $apply_condition === 'cart_qtd_total' ) {
            // get cart info
            foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
                $quantity = $cart_item['quantity'];
        
                // build the conditional expression
                $expression = "($quantity $conditional_operator $condition_value)";
        
                // stop if condition is not match
                if ( empty( $condition_value ) || !eval("return $expression;") ) {
                    return false;
                } else {
                    return true;
                }
            }
        } elseif ( $apply_condition === 'cart_value_total' ) {
            // get cart total value
            $cart_total = $cart->get_cart_contents_total();
            // build the conditional expression
            $expression = "($cart_total $conditional_operator $condition_value)";

            // stop if condition is not match
            if ( empty( $condition_value ) || !eval("return $expression;") ) {
                return false;
            } else {
                return true;
            }
        } elseif ( $apply_condition === 'user_level' ) {
            $current_user_level = get_user_meta( $user_id, 'user_level', true );
            // build the conditional expression
            $expression = "($current_user_level $conditional_operator $condition_value)";

            // stop if condition is not match
            if ( empty( $condition_value ) || !eval("return $expression;") ) {
                return false;
            } else {
                return true;
            }
        } elseif ( $apply_condition === '0' ) {
            return true;
        }

        return false;
    }


    /**
     * Check uses limit for user and date start or end conditions
     * 
     * @since 1.0.0
     * @param $user_id
     * @param $loop
     * @param $use_limit
     * @param $start_date
     * @param $end_date
     * @return bool
     */
    public function check_dates_and_limits( $user_id, $i, $use_limit, $start_date, $end_date ) {
        $current_user_limit = get_user_meta( $user_id, 'user_limit_' . $i, true );
        $timezone = get_option('timezone_string');
        date_default_timezone_set($timezone);
        $date_format = get_option('date_format');
        $current_date = date($date_format);
    
        // check use limit for current user     
        if ( !empty( $use_limit ) ) {
            if ( $current_user_limit >= $use_limit ) {
                return false;
            } 
        }
    
        $start_date_condition = true;
        $end_date_condition = true;
    
        // check start date condition
        if ( !empty( $start_date ) ) {
            $start_date_obj = DateTime::createFromFormat( $date_format, $start_date );
            $current_date_obj = DateTime::createFromFormat( $date_format, $current_date );
            
            if ( $start_date_obj && $current_date_obj ) {
                if ( $current_date_obj < $start_date_obj ) {
                    $start_date_condition = false;
                }
            }
        }
    
        // check end date condition
        if ( !empty( $end_date ) ) {
            $end_date_obj = DateTime::createFromFormat( $date_format, $end_date );
            $current_date_obj = DateTime::createFromFormat( $date_format, $current_date );
            
            if ( $end_date_obj && $current_date_obj ) {
                if ( $current_date_obj > $end_date_obj ) {
                    $end_date_condition = false;
                }
            }
        }
    
        return $start_date_condition && $end_date_condition;
    }    


    /**
     * Set use limit for advanced conditions
     * 
     * @since 1.0.0
     * @param $order_id
     * @return void
     */
    public function set_use_limit_after_order( $order_id ) {
        $order = wc_get_order( $order_id );
        $user_id = $order->get_user_id();
    
        if ( $user_id ) {
            $options = get_option( 'slicker-dynamic-price-rules-setting' );
            $i = $options['get_loop_value_advanced_conditions'];
            $current_user_limit = get_user_meta( $user_id, 'user_limit_' . $i, true );
    
            // Verifique se o usuário tem um limite existente
            if ( empty( $current_user_limit ) ) {
                update_user_meta( $user_id, 'user_limit_' . $i, 0 );
            } else {
                $current_user_limit += 1;
                update_user_meta( $user_id, 'user_limit_' . $i, $current_user_limit );
            }
        }
    }
}

new Slicker_Dynamic_Price_Rules_Conditions();