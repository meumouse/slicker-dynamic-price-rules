<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class for handle user levels
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */
class Slicker_Dynamic_Price_Rules_User_Levels {

    /**
     * Construct function
     */
    public function __construct() {
        // register endpoint on WooCommerce
        add_action( 'init', array( $this,  'register_endpoint' ) );

        // add tab on WooCommerce menu items
        add_filter( 'woocommerce_account_menu_items', array( $this, 'add_tab_menu_items' ) );

        // remove user levels tab if not in allowed users group
        add_filter( 'woocommerce_account_menu_items', array( $this, 'remove_user_levels_tab' ) );

        // load content on page
        add_action( 'woocommerce_account_levels_endpoint', array( $this, 'load_content_points_page_settings_user' ) );

        // add select user level on profile user admin
        add_action( 'show_user_profile', array( $this, 'add_user_level_select_field' ) );
        add_action( 'edit_user_profile', array( $this, 'add_user_level_select_field' ) );

        // save update select level user on profile user admin
        add_action( 'personal_options_update', array( $this, 'save_user_level_field' ) );
        add_action( 'edit_user_profile_update', array( $this, 'save_user_level_field' ) );

        // check condition to pass the level
        add_action( 'template_redirect', array( $this, 'check_user_level_conditions' ) );

        // delete user-level metadata if the user is not in the user role group
        add_action( 'template_redirect', array( $this, 'exclude_user_level_for_non_selected_roles' ) );
    }


    /**
     * Register endpoint
     * 
     * @since 1.0.0
     */
    public function register_endpoint() {
        add_rewrite_endpoint('levels', EP_ROOT | EP_PAGES);

        // update permalinks
        flush_rewrite_rules();
    }


    /**
     * Add tab on WooCommerce menu items
     * 
     * @since 1.0.0
     * @param $items
     * @return array
     */
    public function add_tab_menu_items( $items ) {
        $items['levels'] = __( 'Níveis', 'slicker-dynamic-price-rules' );

        return $items;
    }


    /**
     * Remove user levels tab if not in allowed users group
     * 
     * @since 1.0.0
     * @param $items
     * @return array
     */
    public function remove_user_levels_tab( $items ) {
        $selected_user_role = Slicker_Dynamic_Price_Rules_Init::get_setting('user_role_select');
    
        if ( $selected_user_role !== 'all_roles' || Slicker_Dynamic_Price_Rules_Init::get_setting('enable_level_item_panel') !== 'yes' ) {
            $user_id = get_current_user_id();
            $user = get_userdata( $user_id );
            $user_roles = $user->roles;

            // check current user role
            if ( !in_array( $selected_user_role, $user_roles ) ) {
                unset( $items['levels'] );
            }
        }
    
        return $items;
    }
    

    /**
     * Load content on user settings page
     * 
     * @since 1.0.0
     * @return void
     */
    public function load_content_points_page_settings_user() {
        if ( is_user_logged_in() ) {
            $user_id = get_current_user_id();
            $current_user_level_name = $this->get_user_current_level( $user_id );
    
            // Display the user's current level name on the "My Account" page
            echo sprintf( __( 'Seu nível atual: %s', 'slicker-dynamic-price-rules' ), $current_user_level_name );
        }
    }


    /**
     * Add select options with user levels on user profile admin
     * 
     * @since 1.0.0
     * @param $user
     * @return void
     */
    public function add_user_level_select_field( $user ) {
        $customLevelUsers = get_option('slicker_dynamic_price_rules_user_levels');
        $customLevelUsers = maybe_unserialize( $customLevelUsers );
        $limit_levels = Slicker_Dynamic_Price_Rules_Init::get_setting('set_limit_levels');
        $select_options = array();
        $selected_user_role = Slicker_Dynamic_Price_Rules_Init::get_setting('user_role_select');
    
        // check if user role is allowed for add select with user levels
        if ( $selected_user_role !== 'all_roles' ) {
            $user_id = get_current_user_id();
            $user = get_userdata( $user_id );
            $user_roles = $user->roles;
    
            if ( !in_array( $selected_user_role, $user_roles ) ) {
                return;
            }
        }

        for ( $i = 1; $i <= $limit_levels; $i++ ) {
            $current_user_level_name = isset($customLevelUsers[$i]['name']) ? $customLevelUsers[$i]['name'] : 'Nível ' . $i;
            $select_options[$i] = $current_user_level_name;
        }
    
        // get user level
        $selected_user_level = get_user_meta( $user->ID, 'user_level', true ); ?>

        <h3><?php esc_html_e('Nível de usuário', 'slicker-dynamic-price-rules'); ?></h3>
        <table class="form-table">
            <tr>
                <th><label for="user_level"><?php esc_html_e('Alterar o nível de usuário', 'slicker-dynamic-price-rules'); ?></label></th>
                <td>
                    <select name="user_level" id="user_level">
                        <?php foreach ( $select_options as $level => $label ) : ?>
                            <option value="<?php echo esc_attr( $level ); ?>" <?php selected( $selected_user_level, $level ); ?>><?php echo esc_html( $label ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
        </table>
        <?php
    }


    /**
     * Save user level option
     * 
     * @since 1.0.0
     * @param $user_id
     * @return void
     */
    public function save_user_level_field( $user_id ) {
        if ( current_user_can('edit_user', $user_id) ) {
            update_user_meta($user_id, 'user_level', sanitize_text_field($_POST['user_level']));
        }
    }


    /**
     * Check whether the user has met the condition to pass the level
     * 
     * @since 1.0.0
     * @return void
     */
    public function check_user_level_conditions() {
        if ( is_user_logged_in() ) {
            // Get user level conditions
            $set_conditions_user_levels_exp = get_option('slicker_dynamic_price_rules_user_levels_exp');
            $set_conditions_user_levels_exp = maybe_unserialize( $set_conditions_user_levels_exp );
            $user_id = get_current_user_id();
            $user_order_count = $this->get_user_order_count( $user_id );
            $current_user_level = get_user_meta( $user_id, 'user_level', true );
            $user_points = get_user_meta( $user_id, 'user_points', true );
            $selected_user_role = Slicker_Dynamic_Price_Rules_Init::get_setting('user_role_select');
            $user = get_userdata( $user_id );
            $user_roles = $user->roles;

            if ( empty( $current_user_level ) ) {
                // If the "user_level" metadata is not set, set it to 1
                update_user_meta( $user_id, 'user_level', 1 );
            }

            if ( is_array( $set_conditions_user_levels_exp ) ) {
                $last_available_level = count( $set_conditions_user_levels_exp );
            } else {
                $last_available_level = 0;
            }
    
            // Check if the user is already at the last level and your user role
            if ( $current_user_level < $last_available_level && in_array( $selected_user_role, $user_roles ) ) {
                // Start checking from the next level after the current level
                $next_level = $current_user_level + 1;
    
                // Check if the next level exists and the conditions are met
                if ( isset( $set_conditions_user_levels_exp[ $next_level ] ) ) {
                    $required_exp = $set_conditions_user_levels_exp[ $next_level ]['amount'];
                    $method = $set_conditions_user_levels_exp[ $next_level ]['method'];
    
                    // Check if the method for this level is "purchases"
                    if ( $method == 'purchases' ) {
                        // Check user order quantity
                        if ( $user_order_count >= $required_exp ) {
                            // Upgrade the user level to the next level
                            update_user_meta( $user_id, 'user_level', $next_level );
                        }
                    } elseif ( $method == 'points' ) {
                        // Check user points
                        if ( $user_points >= $required_exp ) {
                            // Upgrade the user level to the next level
                            update_user_meta( $user_id, 'user_level', $next_level );
                        }
                    }
                }
            }
        }
    }


    /**
     * Get user order count
     * 
     * @since 1.0.0
     * @param $user_id
     * @return string
     */
    public function get_user_order_count( $user_id ) {
        if ( class_exists('WooCommerce') ) {
            $order_count = wc_get_customer_order_count( $user_id );

            return $order_count;
        } else {
            return 0;
        }
    }


    /**
     * Get current user level
     * 
     * @since 1.0.0
     * @param $user_id
     * @return string
     */
    public function get_user_current_level( $user_id ) {
        // Obtém o nível atual do usuário a partir dos metadados do usuário
        $current_user_level = get_user_meta( $user_id, 'user_level', true );

        // Obtenha os nomes dos níveis configurados
        $customLevelUsers = get_option('slicker_dynamic_price_rules_user_levels');
        $customLevelUsers = maybe_unserialize( $customLevelUsers );

        // Obtenha o nome do nível atual do usuário
        $current_user_level_name = isset( $customLevelUsers[$current_user_level]['name'] ) ? $customLevelUsers[$current_user_level]['name'] : 'Nível ' . $current_user_level;

        // Retorne o nome do nível atual do usuário
        return $current_user_level_name;
    }


    /**
     * Delete user "user level" metadata if they are not in the allowed user role group
     * 
     * @since 1.0.0
     * @param int $user_id | User ID
     * @return void
     */
    public function exclude_user_level_for_non_selected_roles( $user_id ) {
        $selected_user_role = Slicker_Dynamic_Price_Rules_Init::get_setting('user_role_select');
    
        if ( $selected_user_role !== 'all_roles' ) {
            $user_id = get_current_user_id();
            $user = get_userdata( $user_id );
            $user_roles = $user->roles;
    
            if ( !in_array( $selected_user_role, $user_roles ) ) {
                delete_user_meta( $user_id, 'user_level' );
            }
        }
    }
}

new Slicker_Dynamic_Price_Rules_User_Levels();