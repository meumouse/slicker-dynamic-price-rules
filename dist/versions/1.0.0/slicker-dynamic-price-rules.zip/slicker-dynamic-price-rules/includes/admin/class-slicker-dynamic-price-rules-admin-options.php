<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class for include admin options
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */
class Slicker_Dynamic_Price_Rules_Admin_Options extends Slicker_Dynamic_Price_Rules_Init {

  /**
   * Slicker_Dynamic_Price_Rules_Admin constructor
   *
   * @since 1.0.0
   * @return void
   */
  public function __construct() {
    parent::__construct();

    add_action( 'admin_menu', array( $this, 'slicker_dynamic_price_rules_admin_menu' ) );
    add_action( 'admin_enqueue_scripts', array( $this, 'slicker_dynamic_price_rules_admin_scripts' ), 100 );
    add_action( 'wp_ajax_slicker_dynamic_price_rules_ajax_save_options', array( $this, 'slicker_dynamic_price_rules_ajax_save_options_callback' ) );
    add_action( 'wp_ajax_get_woo_products_ajax', array( $this, 'get_woo_products_ajax' ) );
    add_action( 'wp_ajax_get_woo_categories_ajax', array( $this, 'get_woo_categories_ajax' ) );
    add_action( 'wp_ajax_get_woo_attributes_ajax', array( $this, 'get_woo_attributes_ajax' ) );
    add_action( 'wp_ajax_search_users', array( $this, 'search_users_ajax' ) );
    add_action( 'wp_ajax_process_price_offer', array( $this, 'process_price_offer' ) );
    add_action( 'wp_ajax_update_offer_status', array( $this, 'update_offer_status' ) );
  }

  /**
   * Function for create submenu in settings
   * 
   * @since 1.0.0
   * @return array
   */
  public function slicker_dynamic_price_rules_admin_menu() {
    add_submenu_page(
      'woocommerce', // parent page slug
      esc_html__( 'Slicker - Regras de precificação dinâmicas', 'slicker-dynamic-price-rules'), // page title
      esc_html__( 'Regras de precificação', 'slicker-dynamic-price-rules'), // submenu title
      'manage_woocommerce', // user capabilities
      'slicker-dynamic-price-rules', // page slug
      array( $this, 'slicker_dynamic_price_rules_settings_page' ) // public function for print content page
    );
  }


  /**
   * Plugin general setting page and save options
   * 
   * @since 1.0.0
   * @return void
   */
  public function slicker_dynamic_price_rules_settings_page() {
    include_once SLICKER_DYNAMIC_PRICE_RULES_INC_DIR . 'admin/settings.php';
  }


  /**
   * Enqueue admin scripts in page settings only
   * 
   * @since 1.0.0
   * @return void
   */
  public function slicker_dynamic_price_rules_admin_scripts() {
    $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    
    if ( false !== strpos( $url, 'admin.php?page=slicker-dynamic-price-rules' ) ) {
      wp_enqueue_media();
      wp_enqueue_script( 'slicker-dynamic-price-rules-admin-scripts', SLICKER_DYNAMIC_PRICE_RULES_ASSETS_URL . 'admin/js/slicker-dynamic-price-rules-admin-scripts.js', array('jquery', 'media-upload'), SLICKER_DYNAMIC_PRICE_RULES_VERSION );
      wp_enqueue_style( 'slicker-dynamic-price-rules-admin-styles', SLICKER_DYNAMIC_PRICE_RULES_ASSETS_URL . 'admin/css/slicker-dynamic-price-rules-admin-styles.css', array(), SLICKER_DYNAMIC_PRICE_RULES_VERSION );
      wp_enqueue_script( 'bootstrap-datepicker-lib', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js', array('jquery'), '1.9.0' );
      wp_enqueue_script( 'bootstrap-datepicker-translate-pt-br', SLICKER_DYNAMIC_PRICE_RULES_ASSETS_URL . 'admin/js/bootstrap-datepicker.pt-BR.min.js', array('jquery'), '1.9.0' );

      // get payment methods
      $payment_gateways = WC()->payment_gateways->payment_gateways();
      $gateway_options = array();
  
      foreach ( $payment_gateways as $gateway_id => $gateway ) {
        $gateway_options[$gateway_id] = esc_html( $gateway->get_title() );
      }

      // get shipping methods
      $shipping_methods = WC()->shipping->get_shipping_methods();
      $shipping_options = array();

      foreach ( $shipping_methods as $shipping_id => $shipping ) {
        $shipping_options[$shipping_id] = esc_html( $shipping->method_title );
      }

      // translate existing user roles
      $user_role_translations = array(
        'subscriber' => __( 'Assinante', 'slicker-dynamic-price-rules' ),
        'editor' => __( 'Editor', 'slicker-dynamic-price-rules' ),
        'author' => __( 'Autor', 'slicker-dynamic-price-rules' ),
        'contributor' => __( 'Colaborador', 'slicker-dynamic-price-rules' ),
        'administrator' => __( 'Administrador', 'slicker-dynamic-price-rules' ),
        'customer' => __( 'Cliente', 'slicker-dynamic-price-rules' ),
        'shop_manager' => __( 'Gerente de loja', 'slicker-dynamic-price-rules' ),
      );

      $user_roles = wp_roles()->roles;

      foreach ( $user_roles as $role_key => $role ) {
        $translated_role_name = isset( $user_role_translations[$role_key] ) ? $user_role_translations[$role_key] : $role['name'];
        $role_options[$role_key] = esc_html( $role['name'] );
      }

      wp_localize_script( 'slicker-dynamic-price-rules-admin-scripts', 'sdpr_admin_params', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'wp_media_modal_title' => __( 'Escolher ícone para Ponto', 'slicker-dynamic-price-rules' ),
        'wp_media_modal_button' => __( 'Usar esta imagem', 'slicker-dynamic-price-rules' ),
        'discount_condition_type_percentage' => __( 'Percentual (%)', 'slicker-dynamic-price-rules' ),
        'discount_condition_type_fixed' => sprintf( __( 'Valor fixo (%s)', 'slicker-dynamic-price-rules' ), get_woocommerce_currency_symbol() ),
        'discount_condition_gateway_empty' => __( 'Selecione uma forma de pagamento', 'slicker-dynamic-price-rules' ),
        'gateway_option' => $gateway_options,
        'adv_conditions_shipping_empty' => __( 'Selecione uma forma de entrega', 'slicker-dynamic-price-rules' ),
        'shipping_option' => $shipping_options,
        'role_option' => $role_options,
        'shipping_label' => __( 'Forma de entrega', 'slicker-dynamic-price-rules' ),
        'rule_type_label' => __( 'Tipo da regra *', 'slicker-dynamic-price-rules' ),
        'rule_type_empty' => __( 'Selecione um tipo de regra', 'slicker-dynamic-price-rules' ),
        'rule_type_discount' => __( 'Desconto', 'slicker-dynamic-price-rules' ),
        'rule_type_shipping' => __( 'Forma de entrega', 'slicker-dynamic-price-rules' ),
        'rule_type_operator_empty' => __( 'Selecione um operador', 'slicker-dynamic-price-rules' ),
        'rule_type_operator_remove' => __( 'Remover', 'slicker-dynamic-price-rules' ),
        'rule_type_operator_add' => __( 'Adicionar', 'slicker-dynamic-price-rules' ),
        'user_role_label' => __( 'Selecionar Usuário/Função *', 'slicker-dynamic-price-rules' ),
        'user_role_all_users' => __( 'Todos os usuários (Padrão)', 'slicker-dynamic-price-rules' ),
        'user_role_all_roles' => __( 'Todas as funções', 'slicker-dynamic-price-rules' ),
        'user_role_specific_users' => __( 'Usuários específicos', 'slicker-dynamic-price-rules' ),
        'user_role_specific_roles' => __( 'Função específica', 'slicker-dynamic-price-rules' ),
        'product_filter_label' => __( 'Filtro de produtos *', 'slicker-dynamic-price-rules' ),
        'product_filter_all_products' => __( 'Todos os produtos (Padrão)', 'slicker-dynamic-price-rules' ),
        'product_filter_all_categories' => __( 'Todas as categorias', 'slicker-dynamic-price-rules' ),
        'product_filter_all_attributes' => __( 'Todos os atributos', 'slicker-dynamic-price-rules' ),
        'product_filter_specific_products' => __( 'Produtos específicos', 'slicker-dynamic-price-rules' ),
        'product_filter_specific_categories' => __( 'Categorias específicas', 'slicker-dynamic-price-rules' ),
        'product_filter_specific_attributes' => __( 'Atributos específicos', 'slicker-dynamic-price-rules' ),
        'search_placeholder' => __( 'Comece a digitar para pesquisar...', 'slicker-dynamic-price-rules' ),
        'discount_label' => __( 'Configure a aplicação do desconto', 'slicker-dynamic-price-rules' ),
        'discount_cart' => __( 'Desconto no carrinho (Padrão)', 'slicker-dynamic-price-rules' ),
        'discount_quantity' => __( 'Desconto baseado em quantidade', 'slicker-dynamic-price-rules' ),
        'min_qtd_placeholder' => __( 'Quantidade mínima', 'slicker-dynamic-price-rules' ),
        'discount_method_percentage' => __( 'Percentual (%)', 'slicker-dynamic-price-rules' ),
        'discount_method_fixed' => sprintf( __( 'Valor fixo (%s)', 'slicker-dynamic-price-rules' ), get_woocommerce_currency_symbol() ),
        'discount_value_placeholder' => __( 'Insira o valor de desconto', 'slicker-dynamic-price-rules' ),
        'conditions_label' => __( 'Configure as condições (Opcional)', 'slicker-dynamic-price-rules' ),
        'empty_condition' => __( 'Selecione um tipo de condição', 'slicker-dynamic-price-rules' ),
        'conditions_cart_qtd_total' => __( 'Quantidade total do carrinho', 'slicker-dynamic-price-rules' ),
        'conditions_cart_value_total' => __( 'Valor total do carrinho', 'slicker-dynamic-price-rules' ),
        'conditions_user_level' => __( 'Nível do usuário', 'slicker-dynamic-price-rules' ),
        'operator_condition_empty' => __( 'Selecione um operador', 'slicker-dynamic-price-rules' ),
        'operator_condition_less_than' => __( 'Menor que (<)', 'slicker-dynamic-price-rules' ),
        'operator_condition_less_than_or_equal' => __( 'Menor ou igual a (<=)', 'slicker-dynamic-price-rules' ),
        'operator_condition_greater_than' => __( 'Maior que (>)', 'slicker-dynamic-price-rules' ),
        'operator_condition_greater_than_or_equal' => __( 'Maior ou igual a (>=)', 'slicker-dynamic-price-rules' ),
        'operator_condition_equal' => __( 'Igual (==)', 'slicker-dynamic-price-rules' ),
        'operator_condition_different' => __( 'Diferente (!=)', 'slicker-dynamic-price-rules' ),
        'condition_value_plceholder' => __( 'Insira o valor de condição', 'slicker-dynamic-price-rules' ),
        'manage_limit_label' => __( 'Configure data e limite (Opcional)', 'slicker-dynamic-price-rules' ),
        'manage_limit_use' => __( 'Limite de usos por usuário', 'slicker-dynamic-price-rules' ),
        'manage_limit_use_placeholder' => __( 'Insira o limite de uso', 'slicker-dynamic-price-rules' ),
        'manage_limit_start_date' => __( 'Data de início', 'slicker-dynamic-price-rules' ),
        'manage_limit_end_date' => __( 'Data de finalização', 'slicker-dynamic-price-rules' ),
      ) );
    }
  }


  /**
   * Save options in AJAX
   * 
   * @since 1.0.0
   * @return void
   */
  public function slicker_dynamic_price_rules_ajax_save_options_callback() {
    if ( isset( $_POST['form_data'] ) ) {
        // Convert serialized data into an array
        parse_str( $_POST['form_data'], $form_data );

        $options = get_option( 'slicker-dynamic-price-rules-setting' );
        $options['enable_user_levels'] = isset( $form_data['enable_user_levels'] ) ? 'yes' : 'no';
        $options['enable_level_item_panel'] = isset( $form_data['enable_level_item_panel'] ) ? 'yes' : 'no';
        $options['show_price_for_logged_users'] = isset( $form_data['show_price_for_logged_users'] ) ? 'yes' : 'no';
        $options['enable_budge_feature'] = isset( $form_data['enable_budge_feature'] ) ? 'yes' : 'no';
        $options['enable_bargain_prices'] = isset( $form_data['enable_bargain_prices'] ) ? 'yes' : 'no';
        $options['enable_name_field'] = isset( $form_data['enable_name_field'] ) ? 'yes' : 'no';
        $options['enable_lastname_field'] = isset( $form_data['enable_lastname_field'] ) ? 'yes' : 'no';
        $options['enable_social_reason_field'] = isset( $form_data['enable_social_reason_field'] ) ? 'yes' : 'no';
        $options['enable_phone_field'] = isset( $form_data['enable_phone_field'] ) ? 'yes' : 'no';
        $options['enable_email_field'] = isset( $form_data['enable_email_field'] ) ? 'yes' : 'no';
        $options['enable_type_service_field'] = isset( $form_data['enable_type_service_field'] ) ? 'yes' : 'no';
        $options['enable_deadline_field'] = isset( $form_data['enable_deadline_field'] ) ? 'yes' : 'no';
        $options['enable_aditional_info_field'] = isset( $form_data['enable_aditional_info_field'] ) ? 'yes' : 'no';

        // save settings for user levels
        if ( isset( $form_data['set_user_level'] ) && is_array( $form_data['set_user_level'] ) ) {
          $set_user_levels = $form_data['set_user_level'];
          $settings_array = maybe_serialize( $form_data['set_user_level'] );
          
          update_option( 'slicker_dynamic_price_rules_user_levels', $settings_array );
        }

        // save settings for user levels experience
        if ( isset( $form_data['set_user_level_exp'] ) && is_array( $form_data['set_user_level_exp'] ) ) {
          $set_user_level_exp = $form_data['set_user_level_exp'];
          $settings_array = maybe_serialize( $form_data['set_user_level_exp'] );
          
          update_option( 'slicker_dynamic_price_rules_user_levels_exp', $settings_array );
        }

        // save settings for user levels discount conditions
        if ( isset( $form_data['set_user_level_discounts'] ) && is_array( $form_data['set_user_level_discounts'] ) ) {
          $set_user_level_discounts = $form_data['set_user_level_discounts'];
          $settings_array = maybe_serialize( $form_data['set_user_level_discounts'] );
          
          update_option( 'slicker_dynamic_price_rules_discount_conditions_user_levels', $settings_array );
        }

        // save settings for enabled payment method
        if ( isset( $form_data['enabled_gateway'] ) && is_array( $form_data['enabled_gateway'] ) ) {
          $enabled_gateway = $form_data['enabled_gateway'];
          $settings_array = maybe_serialize( $enabled_gateway );
          
          update_option( 'slicker_dynamic_price_rules_enable_payment_methods_condition', $settings_array );
        }

        // save settings for advanced conditions
        if ( isset( $form_data['advanced_condition'] ) && is_array( $form_data['advanced_condition'] ) ) {
          $advanced_condition = $form_data['advanced_condition'];
          $settings_array = maybe_serialize( $advanced_condition );
          
          update_option( 'slicker_dynamic_price_rules_advanced_conditions', $settings_array );
        }

        // save settings for manage budgets
        if ( isset( $form_data['manage_budget'] ) && is_array( $form_data['manage_budget'] ) ) {
            $budget_settings = $form_data['manage_budget'];
            $user_budgets = get_option('slicker_dynamic_price_rules_user_budgets', array());
            $user_budgets = maybe_unserialize( $user_budgets );

            // Iterate through the updated data
            foreach ( $budget_settings as $budget_id => $updated_data ) {
              if ( isset( $user_budgets[$budget_id] ) ) {
                  // Merge updated data with existing budget data
                  $user_budgets[$budget_id] = array_merge( $user_budgets[$budget_id], $updated_data );
              }
            }

            // Update option with merged data
            update_option('slicker_dynamic_price_rules_user_budgets', maybe_serialize( $user_budgets ) );
        }

        // Merge the form data with the default options
        $updated_options = wp_parse_args( $form_data, $options );

        // Save the updated options
        update_option( 'slicker-dynamic-price-rules-setting', $updated_options );

        $response = array(
          'status' => 'success',
          'options' => $updated_options,
        );

        echo wp_json_encode( $response ); // Send JSON response
    }

    wp_die();
  }


  /**
   * Get product name via AJAX
   * 
   * @since 1.0.0
   * @return void
   */
  public function get_woo_products_ajax() {
    $search_query = sanitize_text_field( $_POST['search_query'] );
    
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        's' => $search_query
    );
    
    $products = new WP_Query( $args );
    
    if ( $products->have_posts() ) {
        while ( $products->have_posts() ) {
            $products->the_post();
            echo '<li class="list-group-item select-specific-product-'. get_the_ID() .'" data-product-id="'. get_the_ID() .'">' . get_the_title() . '</li>';
        }
    } else {
        echo esc_html__( 'Nenhuma produto encontrado.', 'slicker-dynamic-price-rules' );
    }
    
    die();
  }


  /**
   * Get WooCommerce product categories via AJAX
   * 
   * @since 1.0.0
   * @return void
   */
  public function get_woo_categories_ajax() {
    $search_query = sanitize_text_field( $_POST['search_query'] );
    
    $args = array(
        'taxonomy' => 'product_cat',
        'hide_empty' => false,
        'name__like' => $search_query
    );
    
    $categories = get_terms( $args );
    
    if ( !empty( $categories ) ) {
        foreach ( $categories as $category ) {
            echo '<li class="list-group-item select-specific-category-'. $category->term_id .'" data-category-id="'. $category->term_id .'">'. $category->name .'</li>';
        }
    } else {
        echo esc_html__( 'Nenhuma categoria encontrada.', 'slicker-dynamic-price-rules' );
    }
    
    die();
  }


  /**
   * Get product attributes in AJAX
   * 
   * @since 1.0.0
   * @return void
   */
  public function get_woo_attributes_ajax() {
    $search_query = sanitize_text_field( $_POST['search_query'] );

    // get all registered attribute taxonomies
    $attribute_taxonomies = wc_get_attribute_taxonomies();

    if ( ! empty( $attribute_taxonomies ) ) {
        foreach ( $attribute_taxonomies as $attribute_taxonomy ) {
            // Use the taxonomy name instead of the 'attribute_name'
            $taxonomy_name = 'pa_' . $attribute_taxonomy->attribute_name;

            // Verify that the taxonomy name contains the search term
            if ( strpos( $taxonomy_name, $search_query ) !== false ) {
                $args = array(
                    'taxonomy' => $taxonomy_name,
                    'hide_empty' => false,
                );

                $attributes = get_terms( $args );

                if ( ! empty( $attributes ) ) {
                    foreach ( $attributes as $attribute ) {
                        echo '<li class="list-group-item select-specific-attribute-' . $attribute->term_id . '" data-attribute-id="' . $attribute->term_id . '">' . $attribute->name . '</li>';
                    }
                }
            }
        }
    }

    if ( empty( $attributes ) ) {
        echo esc_html__( 'Nenhum atributo encontrado.', 'slicker-dynamic-price-rules' );
    }

    die();
  }


  /**
   * Search WP users in AJAX
   * 
   * @since 1.0.0
   * @return void
   */
  public function search_users_ajax() {
    // Receive search term from AJAX request
    $search_query = sanitize_text_field( $_POST['search_query'] );

    // Run a query to search for users based on the search term
    $args = array(
        'search' => '*' . $search_query . '*',
        'search_columns' => array('user_login', 'user_email', 'user_nicename', 'display_name'),
        'number' => -1, // Return all results
    );

    $users = get_users( $args );

    if ( !empty( $users ) ) {
        $output = '';

        foreach ( $users as $user ) {
            $output .= '<li class="list-group-item select-specific-user-' . $user->ID . '" data-user-id="' . $user->ID . '">' . $user->display_name . '</li>';
        }

        echo $output;
    } else {
        echo esc_html__( 'Nenhum usuário encontrado.', 'slicker-dynamic-price-rules' );
    }

    wp_die();
  }


  /**
   * Send negotiate price offer via AJAX
   * 
   * @since 1.0.0
   * @return void
   */
  public function process_price_offer() {
    if ( Slicker_Dynamic_Price_Rules_Init::get_setting('enable_bargain_prices') !== 'yes' ) {
        return;
    }

    if( isset( $_POST['sdpr_product_id'] ) && isset( $_POST['negotiated_price'] ) && isset( $_POST['sdpr_user_id'] ) ) {
        $product_id = sanitize_text_field($_POST['sdpr_product_id']);
        $negotiated_price = sanitize_text_field($_POST['negotiated_price']);
        $user_id = sanitize_text_field($_POST['sdpr_user_id']);
        $product = wc_get_product( $product_id );
        $original_price = $product->get_regular_price();
        $existing_offers = get_option('prices_negotiated_by_users', array());
        $status = 'pending';

        // Adicione a nova oferta à matriz de ofertas
        $new_offer = array(
            'user_id' => $user_id,
            'product_id' => $product_id,
            'negotiated_price' => $negotiated_price,
            'original_price' => $original_price,
            'status' => $status,
        );

        $existing_offers[] = $new_offer;

        // Salve as ofertas atualizadas na opção
        update_option('prices_negotiated_by_users', $existing_offers);

        // Informações adicionais para o e-mail
        $product_name = $product->get_name();
        $user_email = get_userdata( $user_id )->user_email;

        // Mensagem de e-mail personalizada
        $subject = 'Você recebeu uma nova oferta para um produto';
        $message = 'Uma nova oferta foi recebida para o produto:';
        $message .= '<br>';
        $message .= 'Produto: ' . $product_name . '<br>';
        $message .= 'ID do produto: ' . $product_id . '<br>';
        $message .= 'Preço original: R$' . number_format($original_price, 2, ',', '.') . '<br>';
        $message .= 'Preço ofertado: R$' . number_format($negotiated_price, 2, ',', '.') . '<br>';
        $message .= 'ID do usuário: ' . $user_id . '<br>';
        $message .= 'E-mail do usuário: ' . $user_email . '<br>';

        $headers = array('Content-Type: text/html; charset=UTF-8');

        // Envie o e-mail para o administrador
        $to = get_option('admin_email');
        wp_mail( $to, $subject, $message, $headers );

        // Retorne uma resposta JSON para indicar o sucesso
        $response = array(
            'status' => 'success',
            'message' => 'Oferta enviada com sucesso!',
        );

        echo json_encode( $response );
    } else {
        $response = array(
            'status' => 'error',
            'message' => 'Erro ao processar a oferta.',
        );

        echo json_encode( $response );
    }

    wp_die();
  }


  /**
   * Update offer status
   * 
   * @since 1.0.0
   * @return void
   */
  public function update_offer_status() {
    $settings = self::get_setting;

    if ( Slicker_Dynamic_Price_Rules_Init::get_setting('enable_bargain_prices') !== 'yes' ) {
        return;
    }

    if ( isset( $_POST['offer_id'] ) && isset( $_POST['status'] ) && isset( $_POST['product_id'] ) && isset( $_POST['negotiated_price'] ) ) {
        $user_id = sanitize_text_field($_POST['offer_id']);
        $status = sanitize_text_field($_POST['status']);
        $product_id = sanitize_text_field($_POST['product_id']);
        $negotiated_price = sanitize_text_field($_POST['negotiated_price']);
        $existing_offers = get_option('prices_negotiated_by_users', array());

        // Percorra as ofertas existentes
        foreach ( $existing_offers as &$offer ) {
            if ( $offer['user_id'] === $user_id && $offer['product_id'] === $product_id && $offer['negotiated_price'] === $negotiated_price ) {
                // Atualize o status da oferta
                $offer['status'] = $status;

                // Obtém o usuário que fez a oferta
                $user = get_userdata($user_id);
                $user_email = $user->user_email;
                $product = wc_get_product($product_id);
                $product_name = $product->get_name();
                $negotiated_price_formatted = wc_price($negotiated_price);

                // Cria o cabeçalho para o e-mail
                $headers = array('Content-Type: text/html; charset=UTF-8');

                if ( $status === 'accepted' ) {
                    // Oferta aceita, envia um e-mail para o usuário
                    $subject = 'Sua oferta foi aceita';
                    $message = 'Sua oferta para o produto "' . $product_name . '" foi aceita.' . "\n";
                    $message .= 'Valor ofertado: ' . $negotiated_price_formatted . "\n";

                    wp_mail($user_email, $subject, $message, $headers);
                } elseif ($status === 'declined') {
                    // Oferta recusada, envia um e-mail para o usuário
                    $subject = 'Sua oferta foi recusada';
                    $message = 'Sua oferta para o produto "' . $product_name . '" foi recusada.' . "\n";

                    wp_mail($user_email, $subject, $message, $headers);
                }
            }
        }

        // Atualize as ofertas existentes
        update_option('prices_negotiated_by_users', $existing_offers);

        echo json_encode(array('status' => 'success'));
    } else {
        echo json_encode(array('status' => 'error'));
    }

    wp_die();
  }

}

new Slicker_Dynamic_Price_Rules_Admin_Options();