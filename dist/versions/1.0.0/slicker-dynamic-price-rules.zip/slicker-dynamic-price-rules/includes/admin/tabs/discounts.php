<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
  
?>

<div id="discounts" class="nav-content">
  <table class="form-table">
      <tr class="set-user-levels d-none">
         <th>
            <?php echo esc_html__( 'Descontos por forma de pagamento para cada nível', 'slicker-dynamic-price-rules' ) ?>
            <span class="slicker-dynamic-price-rules-description"><?php echo esc_html__( 'Define o tipo de condição necessária para aplicar descontos, métodos e formas de pagamentos para cada nível.', 'slicker-dynamic-price-rules' ) ?></span>
         </th>
         <td>
          <fieldset id="set-discount-conditions-user-levels-fieldset">
              <?php
              $discount_conditions = get_option('slicker_dynamic_price_rules_discount_conditions_user_levels');
              $discount_conditions = maybe_unserialize( $discount_conditions );
              $discount_conditions = array();
              $limit_levels = self::get_setting('set_limit_levels');

              for ( $i = 1; $i <= $limit_levels; $i++ ) {
                $user_levels = get_option('slicker_dynamic_price_rules_user_levels');
                $user_levels = maybe_unserialize( $user_levels );
                $current_user_level = $user_levels[$i] ?? array();
                $current_user_level_name = isset( $current_user_level['name'] ) ? $current_user_level['name'] : 'Nível ' . $i;
                $discount_conditions = get_option('slicker_dynamic_price_rules_discount_conditions_user_levels');
                $discount_conditions = maybe_unserialize( $discount_conditions );
                
                if ( !isset( $discount_conditions[$i] ) ) {
                    $discount_conditions[$i] = array(
                        'condition' => 1,
                        'discounts' => array(),
                    );
                }
                
                $current_user_level_conditions = $discount_conditions[$i]['condition']; ?>

                  <div class="levels-conditions-item" data-condition-item="<?php echo $i; ?>">
                      <div class="input-group mb-3">
                          <input type="text" class="get-user-level-number-array input-control-wd-10 border-right-0" disabled value="<?php echo esc_html($current_user_level_name); ?>"/>
                          <a class="sdpr-display-popup trigger-<?php echo $i; ?> btn btn-outline-primary line-height-2-2" href="#" data-popup="<?php echo $i; ?>"><?php echo esc_html__('Configurar descontos', 'slicker-dynamic-price-rules') ?></a>
                      </div>

                      <div class="sdpr-popup-container container-item-<?php echo $i; ?>" data-popup-container="<?php echo $i; ?>">
                          <div class="sdpr-popup-content content-item-<?php echo $i; ?>">
                              <div class="sdpr-popup-header">
                                  <h5 class="sdpr-popup-title"><?php echo sprintf(__('Descontos para %s', 'slicker-dynamic-price-rules'), esc_html($current_user_level_name)); ?></h5>
                                  <button class="sdpr-close-popup btn-close fs-lg" aria-label="Fechar"></button>
                              </div>
                              <span class="d-block text-left mb-4"><?php echo esc_html__('Adicione condições de descontos para cada forma de pagamento do nível do usuário.', 'slicker-dynamic-price-rules') ?></span>

                              <input type="hidden" class="get-value-for-payment-condition hidden-condition-input" name="set_user_level_discounts[<?php echo $i; ?>][condition]" value="<?php echo esc_attr($current_user_level_conditions); ?>" data-level="<?php echo $i; ?>" data-current-value="<?php echo esc_attr($current_user_level_conditions); ?>"/>

                              <div class="levels-condition-items-container discount-container-item-<?php echo $i; ?>">
                                  <?php
                                  for ( $p = 1; $p <= $current_user_level_conditions; $p++ ) {
                                      $current_user_level_condition = $discount_conditions[$i][$p] ?? array();
                                      $current_user_level_amount = isset($current_user_level_condition['amount']) ? floatval($current_user_level_condition['amount']) : 0;
                                      $current_user_level_discount = isset($current_user_level_condition['type']) ? $current_user_level_condition['type'] : 'percentage';
                                      $current_user_level_gateway = isset($current_user_level_condition['gateway']) ? $current_user_level_condition['gateway'] : '';
                                      
                                      $discount_conditions[$i]['discounts'][$p] = array(
                                        'gateway' => $current_user_level_gateway,
                                        'amount' => $current_user_level_amount,
                                        'type' => $current_user_level_discount,
                                      ); ?>

                                      <div class="levels-condition-item d-flex" data-discount-condition="<?php echo $i; ?>" data-levels-condition-item="<?php echo $p; ?>">
                                          <div class="input-group mb-3">
                                              <input type="text" class="form-control input-control-wd-5 border-right-0 allow-numbers-be-1 text-center" data-discount-amount="<?php echo $i; ?>" data-discount-amount-item="<?php echo $p; ?>" name="set_user_level_discounts[<?php echo $i; ?>][<?php echo $p; ?>][amount]" placeholder="3" value="<?php echo esc_attr($current_user_level_amount); ?>"/>
                                              
                                              <select class="form-select select-middle-group" data-select-discount-type="<?php echo $i; ?>" data-discount-item="<?php echo $p; ?>" name="set_user_level_discounts[<?php echo $i; ?>][<?php echo $p; ?>][type]">
                                                  <option value="percentage" <?php echo esc_attr($current_user_level_discount) == 'percentage' ? "selected=selected" : ""; ?>><?php echo esc_html__('Percentual (%)', 'slicker-dynamic-price-rules') ?></option>
                                                  <option value="fixed" <?php echo esc_attr($current_user_level_discount) == 'fixed' ? "selected=selected" : ""; ?>><?php echo sprintf(__('Valor fixo (%s)', 'slicker-dynamic-price-rules'), get_woocommerce_currency_symbol()) ?></option>
                                              </select>

                                              <select class="form-select set-payment-gateway-condition" data-select-gateway-condition="<?php echo $i; ?>" data-gateway-item="<?php echo $p; ?>" name="set_user_level_discounts[<?php echo $i; ?>][<?php echo $p; ?>][gateway]">
                                                  <option value="0"><?php echo esc_html__('Selecione uma forma de pagamento', 'slicker-dynamic-price-rules'); ?></option>
                                                  <?php $payment_gateways = WC()->payment_gateways->payment_gateways();

                                                  foreach ($payment_gateways as $gateway_id => $gateway) {
                                                      echo '<option value="' . esc_attr($gateway_id) . '" ' . (esc_attr($current_user_level_gateway) == esc_attr($gateway_id) ? "selected=selected" : "") . '>' . esc_html($gateway->get_title()) . '</option>';
                                                  }
                                                  ?>
                                              </select>
                                              </div>
                                          <button class="exclude-payment-condition-item btn btn-outline-danger btn-icon ms-3" data-exclude-condition="<?php echo $i; ?>" data-exclude-item="<?php echo $p; ?>">
                                            <svg class="slicker-dynamic-price-rules-danger-icon" width="20" height="20" viewBox="0 0 24 24"><path d="M15 2H9c-1.103 0-2 .897-2 2v2H3v2h2v12c0 1.103.897 2 2 2h10c1.103 0 2-.897 2-2V8h2V6h-4V4c0-1.103-.897-2-2-2zM9 4h6v2H9V4zm8 16H7V8h10v12z"></path></svg>
                                          </button>
                                      </div>
                                  <?php } ?>
                              </div>
                              <button class="add-new-payment-conditions btn-add mt-2" data-add-condition="<?php echo $i; ?>" title="<?php echo esc_html__('Adicionar desconto por forma de pagamento', 'slicker-dynamic-price-rules') ?>"></button>
                          </div>
                      </div>
                  </div>
              <?php } ?>
          </fieldset>
        </td>
      </tr>
  </table>
</div>