<?php

/**
 * Template for view each budget
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Before budget details hook
 *
 * @since 1.0.0
 */
do_action( 'sdpr_budget_content_header' ); ?>

<div class="slicker-dynamic-price-rules-budget-content">
	<?php
	/**
	 * View budget details hook
	 *
	 * @since 1.0.0
	 */
	do_action( 'sdpr_budget_content_details' ); ?>
</div>

<?php do_action( 'sdpr_budget_content_footer' );