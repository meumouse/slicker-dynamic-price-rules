<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Main class init plugin
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */
class Slicker_Dynamic_Price_Rules_Init {
  
    /**
     * Construct function
     * 
     * @since 1.0.0
     * @return void
     */
    public function __construct() {
      add_action( 'plugins_loaded', array( $this, 'slicker_set_default_options' ), 998 );
      add_action( 'admin_init', array( $this, 'load_aditional_features' ) );
    }


    /**
     * Set default plugin settings
     * 
     * @since 1.0.0
     * @return array
     */
    public function set_default_data_options() {
      return array(
        'enable_user_levels' => 'yes',
        'enable_level_item_panel' => 'yes',
        'set_limit_levels' => '3',
        'user_role_select' => 'all_roles',
        'set_amount_for_gain_discount_reference' => '1',
        'show_price_for_logged_users' => 'no',
        'enable_budge_feature' => 'no',
        'enable_bargain_prices' => 'no',
        'get_loop_value_advanced_conditions' => '1',
        'enable_name_field' => 'yes',
        'enable_lastname_field' => 'yes',
        'set_person_type_method' => 'cpf_and_cnpj',
        'enable_social_reason_field' => 'yes',
        'enable_phone_field' => 'yes',
        'enable_email_field' => 'yes',
        'enable_type_service_field' => 'yes',
        'enable_deadline_field' => 'no',
        'enable_aditional_info_field' => 'no',
        'text_social_reason_budget_header' => 'Empresa LTDA.',
        'text_cnpj_budget_header' => 'CNPJ: 12.345.678/0001-20',
        'text_address_budget_header' => 'Rua Fulano de Tal, 100 - Bairro, Cidade - Estado (CEP: 12345-000)',
        'display_logo_budgets' => '',
        'set_primary_color' => '#008aff',
      );
    }


    /**
     * Gets the items from the array and inserts them into the option if it is empty,
     * or adds new items with default value to the option
     * 
     * @since 1.0.0
     * @return void
     */
    public function slicker_set_default_options() {
      $get_options = $this->set_default_data_options();
      $default_options = get_option('slicker_data_options', array());
      $default_options = maybe_unserialize($default_options);
  
      if ( empty( $default_options ) ) {
          $options = $get_options;
          update_option('slicker_data_options', $options);
      } else {
          $options = $default_options;
  
          foreach ( $get_options as $key => $value ) {
              if ( !isset( $options[$key] ) ) {
                  $options[$key] = $value;
              }
          }
  
          update_option('slicker_data_options', $options);
      }
  }    


  /**
   * Checks if the option exists and returns the indicated array item
   * 
   * @since 1.0.0
   * @param $key | Array key
   * @return mixed | string or false
   */
    public static function get_setting( $key ) {
        $default_options = get_option('slicker_data_options', array());

        // check if array key exists and return key
        if ( isset( $default_options[$key] ) ) {
            return $default_options[$key];
        }

        return false;
    }


    /**
     * Check settings for load classes
     * 
     * @since 1.0.0
     * @return void
     */
    public function load_aditional_features() {
      // load user levels class
      if ( self::get_setting('enable_user_levels') === 'yes' ) {
        include_once SLICKER_DYNAMIC_PRICE_RULES_INC_DIR . 'classes/class-slicker-dynamic-price-rules-user-levels.php';
      }

      // load budget class
      if ( self::get_setting('enable_budge_feature') === 'yes' ) {
        include_once SLICKER_DYNAMIC_PRICE_RULES_INC_DIR . 'classes/class-slicker-dynamic-price-rules-budget.php';
      }
    }
}

new Slicker_Dynamic_Price_Rules_Init();