jQuery( function($) {
    const triggerPopup = $('.negotiate-price-trigger');
    const popupContainer = $('.negotiate-popup');
    const closePopup = $('.close-negotiate-popup');
    const offerForm = $('form[name="send-negotiate-product-price"]');

    triggerPopup.on('click', function(e) {
        e.preventDefault();
        popupContainer.addClass('show');
        $('.offer-notification .alert-success, .offer-notification .alert-danger').addClass('d-none');
    });

    popupContainer.on('click', function(event) {
        if (event.target === this) {
            $(this).removeClass('show');
            $('.offer-notification .alert-success, .offer-notification .alert-danger').addClass('d-none');
        }
    });

    closePopup.on('click', function() {
        popupContainer.removeClass('show');
    });

    offerForm.on('submit', function(e) {
        e.preventDefault();

        const product_id = offerForm.find('input[name="sdpr_product_id"]').val();
        const negotiated_price = offerForm.find('input[name="negotiated_price"]').val();
        const user_id = offerForm.find('input[name="sdpr_user_id"]').val();
        let btn = $('.send-offer');
        let original_text = btn.text();
        let btn_width = btn.width();
        let btn_height = btn.height();

        // Mantenha a largura e altura originais do botão
        btn.width(btn_width);
        btn.height(btn_height);

        // Adicione um spinner dentro do botão
        btn.html('<span class="spinner-border spinner-border-sm"></span>');

        $.ajax({
            type: 'POST',
            url: sdpr_np_params.ajax_url,
            data: {
                action: 'process_price_offer',
                sdpr_product_id: product_id,
                negotiated_price: negotiated_price,
                sdpr_user_id: user_id,
            },
            success: function(response) {
                response = JSON.parse(response);
                btn.html(original_text);

                if (response.status === 'success') {
                    $('.offer-notification .alert-success').removeClass('d-none');
                    console.log('Oferta enviada com sucesso!');
                } else {
                    $('.offer-notification .alert-danger').removeClass('d-none');
                    console.error('Erro ao enviar a oferta.');
                }
            },
            error: function() {
                btn.html(original_text);
                $('.offer-notification .alert-danger').removeClass('d-none');
                console.error('Erro ao enviar a oferta.');
            }
        });
    });
});