jQuery(function ($) {
    const triggerPopup = $('.sdpr-budget-popup-trigger');
    const popupContainer = $('.sdpr-budget-container');
    const closePopup = $('.sdpr-close-budget-popup');
    const budgetForm = $('form[name="sdpr-send-budget"]');
    const personTypeSelect = $('#budget_person_type');
    const cpf_field = $('p.cpf-field');
    const cnpj_field = $('p.cnpj-field');
    const social_reason_field = $('p.social-reason-field');

    // Função para exibir ou ocultar campos com base na seleção de "Tipo de Pessoa"
    function toggleFields() {
        const person_type = personTypeSelect.val();

        // Remover o atributo "required" dos campos ocultos
        if (person_type === 'cpf_field') {
            cpf_field.removeClass('d-none');
            cnpj_field.addClass('d-none').find('input').removeAttr('required');
            social_reason_field.addClass('d-none').find('input').removeAttr('required');
        } else if (person_type === 'cnpj_field') {
            cpf_field.addClass('d-none').find('input').removeAttr('required');
            cnpj_field.removeClass('d-none');
            social_reason_field.removeClass('d-none');
        }
    }

    personTypeSelect.on('change', toggleFields);

    triggerPopup.on('click', function (e) {
        e.preventDefault();
        popupContainer.addClass('show');
    });

    popupContainer.on('click', function (event) {
        if (event.target === this) {
            $(this).removeClass('show');
        }
    });

    closePopup.on('click', function () {
        popupContainer.removeClass('show');
    });

    toggleFields();

    // Recupera o valor formatado do cookie, se existir
    var formattedCpfCookie = getCookie('formattedCpf');

    if (formattedCpfCookie) {
        $('#budget_cpf_field').val(formattedCpfCookie);
    }

    var formattedCnpjCookie = getCookie('budget_cnpj');

    if (formattedCnpjCookie) {
        $('#budget_cnpj_field').val(formattedCnpjCookie);
    }
    
    // Recupera o valor da Razão Social do cookie, se existir
    var socialReasonCookie = getCookie('budget_social_reason');
    
    if (socialReasonCookie) {
        $('#budget_social_reason_field').val(socialReasonCookie);
    }
    

    $('#budget_cpf_field').on('input', function() {
        var input = $(this);
        var cpf = input.val().replace(/\D/g, '');
        var formattedCpf = '';
    
        // Limita o CPF a 11 dígitos
        if (cpf.length > 11) {
          cpf = cpf.substring(0, 11);
        }
    
        // Formata o CPF com pontos e traço
        for (var i = 0; i < cpf.length; i++) {
          if (i === 3 || i === 6) {
            formattedCpf += '.';
          } else if (i === 9) {
            formattedCpf += '-';
          }

          formattedCpf += cpf.charAt(i);
        }
    
        // Define o valor formatado de volta no campo de entrada
        input.val(formattedCpf);
    
        // Armazena o valor formatado nos cookies por 30 dias
        var expiryDate = new Date();

        expiryDate.setDate(expiryDate.getDate() + 30);
        document.cookie = 'formattedCpf=' + formattedCpf + '; expires=' + expiryDate.toUTCString() + '; path=/';
    });

    
    // Evento para CNPJ
    $('#budget_cnpj_field').on('input', function() {
        var input = $(this);
        cnpj = input.val().replace(/\D/g, '');
        var formattedCnpj = '';
    
        // Limita o CNPJ a 14 dígitos
        if (cnpj.length > 14) {
          cnpj = cnpj.substring(0, 14);
        }
    
        // Formata o CNPJ
        for (var i = 0; i < cnpj.length; i++) {
          if (i === 2 || i === 5) {
            formattedCnpj += '.';
          } else if (i === 8) {
            formattedCnpj += '/';
          } else if (i === 12) {
            formattedCnpj += '-';
          }
          formattedCnpj += cnpj.charAt(i);
        }

        // Define o valor formatado de volta no campo de entrada
        input.val(formattedCnpj);
        
        // Armazena o valor formatado nos cookies por 30 dias
        var expiryDate = new Date();

        expiryDate.setDate(expiryDate.getDate() + 30);
        document.cookie = 'formattedCnpj=' + formattedCnpj + '; expires=' + expiryDate.toUTCString() + '; path=/';
    });
    
    // Evento para Razão Social
    $('#budget_social_reason_field').on('input', function() {
        var input = $(this);
        var value = input.val();
        
        // Armazena o valor formatado nos cookies por 30 dias
        var expiryDate = new Date();

        expiryDate.setDate(expiryDate.getDate() + 30);
        document.cookie = 'formattedSocialReason=' + value + '; expires=' + expiryDate.toUTCString() + '; path=/';
    });
    
    
    // Função para recuperar um cookie pelo nome
    function getCookie(name) {
        var cookieName = name + '=';
        var cookies = document.cookie.split(';');

        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();

            if (cookie.indexOf(cookieName) === 0) {
                return cookie.substring(cookieName.length, cookie.length);
            }
        }

        return null;
    }

    // send budget action
    budgetForm.on('submit', function (event) {
        event.preventDefault();

        let btn = $('button[name="create_new_budget"]');
        let original_text = btn.text();
        let btn_width = btn.width();
        let btn_height = btn.height();

        // Mantenha a largura e altura originais do botão
        btn.width(btn_width);
        btn.height(btn_height);

        // Adicione um spinner dentro do botão
        btn.html('<span class="spinner-border spinner-border-sm"></span>');

        const formData = {
            action: 'send_budget',
            budget_name_and_last_name: $('#budget_name_and_last_name').val(),
            budget_first_name: $('#budget_first_name').val(),
            budget_last_name: $('#budget_last_name').val(),
            budget_person_type: $('#budget_person_type').val(),
            budget_cpf_field: $('#budget_cpf_field').val(),
            budget_cnpj_field: $('#budget_cnpj_field').val(),
            budget_social_reason_field: $('#budget_social_reason_field').val(),
            budget_phone_number: $('#budget_phone_field').val(),
            budget_service_type: $('#budget_service_type_field').val(),
            budget_deadline: $('#budget_deadline_field').val(),
            budget_aditional_info: $('#budget_aditional_info_field').val(),
        };
        
        $('input[name="send_new_budget"]').val(JSON.stringify(formData));

        $.ajax({
            type: 'POST',
            url: sdpr_budgets_params.ajax_url,
            data: formData,
            success: function (response) {
                btn.html(original_text);
                $('.budget-notification .alert-success').removeClass('d-none');
                console.log(response);
            },
            error: function () {
                btn.html(original_text);
                $('.budget-notification .alert-danger').removeClass('d-none');
                console.error('Erro ao enviar o orçamento.');
            },
        });
    });

    /**
     * Approve budget action
     */
    $('.approve-budget').on('click', function(e) {
        e.preventDefault();

        let budgetId = $(this).data('budget-id');
        let btn = $(this);
        let original_text = btn.text();
        let btn_width = btn.width();
        let btn_height = btn.height();

        btn.width(btn_width);
        btn.height(btn_height);
        btn.html('<span class="spinner-grow spinner-grow-sm"></span>');

        const formData = {
            action: 'customer_aprovation',
            budget_id: budgetId,
            customer_approval: 'approved',
        };

        $.ajax({
            type: 'POST',
            url: sdpr_budgets_params.ajax_url,
            data: formData,
            success: function(response) {
                $('td.customer-aprovation').html('<span class="badge bg-translucent-success text-success">'+ sdpr_budgets_params.budget_approved +'</a>');
                console.log(response);
                btn.html(original_text);
            },
            error: function() {
                console.error('Erro ao enviar a solicitação AJAX.');
                btn.html(original_text);
            },
        });
    });
    
    /**
     * Decline budget action
     */
    $('.decline-budget').on('click', function(e) {
        e.preventDefault();
        
        let budgetId = $(this).data('budget-id');
        let btn = $(this);
        let original_text = btn.text();
        let btn_width = btn.width();
        let btn_height = btn.height();

        // Mantenha a largura e altura originais do botão
        btn.width(btn_width);
        btn.height(btn_height);

        // Adicione um spinner dentro do botão
        btn.html('<span class="spinner-grow spinner-grow-sm"></span>');
        
        const formData = {
            action: 'customer_aprovation',
            budget_id: budgetId,
            customer_approval: 'declined',
        };

        $.ajax({
            type: 'POST',
            url: sdpr_budgets_params.ajax_url,
            data: formData,
            success: function(response) {
                $('td.customer-aprovation').html('<span class="badge bg-translucent-danger text-danger">'+ sdpr_budgets_params.budget_declined +'</a>');
                console.log(response);
                btn.html(original_text);
            },
            error: function() {
                console.error('Erro ao enviar a solicitação AJAX.');
                btn.html(original_text);
            },
        });
    });
});